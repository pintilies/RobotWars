<?php
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

include "Logic/Da/Da.php";
include "Logic/Da/CachingDa.php";
include "Logic/Da/SecurityDa.php";
include "Logic/Da/ResourceDa.php";
include "Logic/Da/SettingDa.php";
include "Logic/Da/LoggingDa.php";
include "Logic/Http/MvcManager.php";
include "Logic/Http/MvcModel.php";
include "Logic/Http/MvConnectParams.php";
include "Logic/Http/SessionManager.php";
include "Logic/Http/HttpResponse.php";
include "Logic/Http/CookieManager.php";
include "Logic/Http/HtmlManager.php";
include "Logic/Caching/CachingManager.php";
//include "Logic/Caching/CacheDispatcherThread.php";
include "Logic/DateTimeManager.php";
include "Logic/Security/SecurityManager.php";
include "Logic/Resources/ResourceManager.php";
include "Logic/LoggingManager.php";
include "Logic/UserManager.php";
include "Logic/SettingManager.php";
include "Logic/Objects/ArrayManager.php";
include "Logic/Objects/ValidatorManager.php";
include "Logic/Objects/NetworkManager.php";
include "Logic/Smtp/EmailManager.php";

class HttpConfig
{
	public static $HomePageUrl = "/";
	public static $ErrorPageUrl = "http://resources.yeuk.me.dev/content/error.html";
	public static $MaintenancePageUrl = "http://resources.yeuk.me.dev/content/maintenance.html";
	public static $MaintenanceOnePageUrl = "http://resources.yeuk.me.dev/content/maintenanceone.html";
	public static $PageSize = 10;
	public static $PageScrolling = 5;
	public static $PageFastScrollLeftString = '<<';
	public static $PageScrollLeftString = '<';
	public static $PageFastScrollRightString = '>>';
	public static $PageScrollRightString = '>';
}

class ServerConfig
{
	public static $Application_App01 = "App01";
	public static $Application_Internal = "Internal";
	public static $Application_Admin = "Admin";

	public static $ApplicationDomains = array
		(
			"App01" => "app01.yeuk.me.dev",
			"Internal" => "internal.yeuk.me.dev",
			"Admin" => "admin.yeuk.me.dev"
		);

	public static $Application = "App01";
	public static $Machine = "Lenovo";
	public static $ServerRoot;
	public static $HttpsCall;
	public static $ServerName;
	public static $CallerIp;
	public static $CallerHostName;
	public static $RequestUri;
	public static $RequestPath;
	public static $UserAgent;
}

ServerConfig::$ServerRoot = $_SERVER['DOCUMENT_ROOT'];
ServerConfig::$HttpsCall = $_SERVER['HTTPS'] && $_SERVER['HTTPS'] == "on";
ServerConfig::$ServerName = $_SERVER['SERVER_NAME'];
ServerConfig::$CallerIp = $_SERVER['REMOTE_ADDR'];
ServerConfig::$CallerHostName = gethostbyaddr(ServerConfig::$CallerIp);
ServerConfig::$RequestUri = $_SERVER['REQUEST_URI'];
ServerConfig::$RequestPath = strtok(ServerConfig::$RequestUri,'?');
ServerConfig::$UserAgent = $_SERVER['HTTP_USER_AGENT'];

foreach (ServerConfig::$ApplicationDomains as $key => $value)
	if (ServerConfig::$ServerName == $value)
	{
		ServerConfig::$Application = $key;
		break;
	}

class MvcConfig
{
	public static $DefaultController = "index";
	public static $DefaultAction = "index";
	public static $HttpServiceRoot = "/Services/App01";
	public static $MvConnector = "/MvConnector.php";

	public static $LayoutRoot = "/Layout";
	public static $DefaultLayout = "/Main";

	public static $ModelResult_Redirect = 1;
	public static $ModelResult_Html = 2;
	public static $ModelResult_Response = 3;
	public static $ModelResult_OtherType = 4;
	public static $ModelResult_ErrorCode = 5;

	public static $SubActionPrefix = "__SUBACTION__";
}

MvcConfig::$HttpServiceRoot = ServerConfig::$ServerRoot."/Services/".ServerConfig::$Application;
MvcConfig::$MvConnector = ServerConfig::$ServerRoot."/Services/".ServerConfig::$Application."/MvConnector.php";

class CachingConfig
{
	public static $TimeCaches = array(
		"BannedIps" => 1800,
		);

	public static $Clients = array(
		//"http://localhost/cache/clear"
		);

	public static $DispatchCyclePeriod = 3;
	public static $NullValue;

	public static $CacheBaseName_Settings = "Settings_";
	public static $CacheBaseName_Settings_Types = "Settings_Types_";
	public static $CacheBaseName_Rights = "Rights_";
	public static $CacheBaseName_Rights_UserTypes = "Rights_UserTypes";
	public static $CacheBaseName_Rights_UserTypeInclusions = "Rights_UserTypeInclusions";
	public static $CacheBaseName_Languages_All = "Languages_All";
	public static $CacheBaseName_Languages_Enabled = "Languages_Enabled";
	public static $CacheBaseName_Resources = "Resources_";
	public static $CacheBaseName_Mvc = "Mvc_";
	public static $CacheBaseName_BannedIps = "BannedIps_";
}

CachingConfig::$NullValue = chr(0);

class MySqlConfig
{
	public static $Host = "127.0.0.1";
	public static $Username = "basesiteuser";
	public static $Password = "password";
	public static $MainDB = "basesite";
	public static $LogDB = "basesite";
}


class SecurityConfig
{
	public static $UserType_Anonymous = 1;
	public static $UserType_WebUser = 2;
}

class LockConfig
{
	public static $SecurityLock = 1;
}

class ResourceConfig
{
	public static $DefaultLanguage = "en";

	public static $Id_InternalMailFromName = 1;
	public static $Id_InternalMailFromAddress = 2;
	public static $Id_InternalMailBodySecurityOverallRequestLimitReached = 3;
	public static $Id_InternalMailBodySecurityIpRequestLimitReached = 4;
	public static $Id_InternalMailSubjectSecurityOverallRequestLimitReached = 6;
	public static $Id_InternalMailSubjectSecurityIpRequestLimitReached = 7;
	public static $Id_InternalMailToAddress = 5;

}

class SessionConfig
{
	public static $Key_UserId = "UserId";
	public static $Key_Language = "Language";
	public static $Key_Username = "Username";
	public static $Key_Email = "Email";
	public static $Key_UserType = "UserType";
	public static $Key_UserTypes = "UserTypes";
	public static $Key_LogId = "LogId";
	public static $Key_RequestId = "RequestId";
	public static $Key_IsMobile = "IsMobile";
	public static $Key_TooManyRequestList = "TooManyRequestList";
	public static $Key_TooManyRequestLastRequest = "TooManyRequestLastRequest";
	public static $Key_TooManyRequestLastLogWarning = "TooManyRequestLastLogWarning";
	public static $Key_IsBlocked = "IsBlocked";
}

class CookieConfig
{
	public static $Key_Language = "Language";
	public static $Key_IsMobile = "IsMobile";
}

class LoggingConfig
{
	public static $MaxIdSize = 4000000000;

	public static $LogType_Info = 'I';
	public static $LogType_Warning = 'W';
	public static $LogType_Error = 'E';
	public static $LogType_Audit = 'A';

	public static $Application = "Website";
	public static $Machine = "Lenovo";

	public static $Category_Info = "INF";
	public static $Category_Debug = "DBG";
	public static $Category_Warning = "WRN";
	public static $Category_Error = "ERR";

	public static $Category_InitRequest = "INI_REQ";
	public static $Category_InvalidUrl = "BAD_URL";
	public static $Category_NoRights = "ACS_FBD";
	public static $Category_NoRightsDefined = "ACS_NRD";
	public static $Category_NoUserTypesDefined = "ACS_NUT";
	public static $Category_TooManyRequestWarning = "ACS_REW";
	public static $Category_TooManyRequestBlocked = "ACS_REB";
	public static $Category_BlockedIp = "ACS_BIP";
	public static $Category_SendingEmailError = "SMT_ERR";
}

LoggingConfig::$Application = ServerConfig::$Application;
LoggingConfig::$Machine = ServerConfig::$Machine;

class SettingConfig
{
	public static $Type_Boolean = 1;
	public static $Type_Integer = 2;
	public static $Type_Decimal = 3;
	public static $Type_DateTime = 4;
	public static $Type_Text = 5;
	public static $Type_CommaEqual = 6;
	public static $Type_CommaEqualInt = 7;
	public static $Type_CommaEqualKeyValue = 8;
	public static $Type_CommaEqualKeyIntValue = 9;
	public static $Type_CommaEqualKeyValueInt = 10;
	public static $Type_CommaEqualKeyIntValueInt = 11;

	public static $Name_LoggingSessionIndex = "Logging_SessionIndex";
	public static $Name_LoggingTable = "Logging_Table";
	public static $Name_LoggingFilterByTypes = "Logging_FilterByTypes";
	public static $Name_LoggingFilterByUserIds = "Logging_FilterByUserIds";
	public static $Name_LoggingFilterByCategories = "Logging_FilterByCategories";
	public static $Name_LoggingHeaders = "Logging_Headers";
	public static $Name_LoggingGet = "Logging_Get";
	public static $Name_LoggingPost = "Logging_Post";
	public static $Name_SecuritySensitiveParameters = "Security_SensitiveParameters";
	public static $Name_SecurityBlockedIps = "Security_BlockedIps";
	public static $Name_SecurityAllowedCrawlers = "Security_AllowedCrawlers";
	public static $Name_SecurityNewRequestCountLimit = "Security_NewRequestCountLimit";
	public static $Name_SecuritySameIpRequestCountLimit = "Security_SameIpRequestCountLimit";
	public static $Name_MaintenanceEnabled = "Maintenance_Enabled";
	public static $Name_MaintenanceAllowedIps = "Maintenance_MaintenanceAllowedIps";
}

class EmailConfig
{
	public static $Host = "127.0.0.1";
	public static $Port = 25;

}

?>
<?php

include "Config.php";

class HttpHandler
{
	public static $ServerRoot;
	public static $errorHandled = 0;

	public static function Init()
	{
		//set_error_handler(array('HttpHandler', 'HandleErrors'), E_ALL);
		//$arr = array_fill(0, 100000, 'A');

		//$str = '';

		//for($i = 0; $i < 100000; $i++)
		//    $str .= $arr[$i];

		//LoggingManager::StartTimer();
		//$len = strlen($str);
		//for($i = 0; $i < $len; $i++)
		//{
		//    $b = $str[$i];
		//}
		//LoggingManager::EndTimer();

		//LoggingManager::StartTimer();

		//$chars = str_split($str);

		//foreach($chars as $char)
		//{
		//    $b = $char;
		//}

		//LoggingManager::EndTimer();

		/*try
		{*/
			SessionManager::Init();
			LoggingManager::Init();

			ResourceManager::Init();
			UserManager::Init();
			SecurityManager::Init();

			if (SettingManager::Get(SettingConfig::$Name_MaintenanceEnabled) && !array_key_exists(ServerConfig::$CallerIp, SettingManager::Get(SettingConfig::$Name_MaintenanceAllowedIps)))
				self::End(HttpConfig::$MaintenancePageUrl);

			SecurityManager::RequestCheck();

			$message = null;

			if (SettingManager::Get(SettingConfig::$Name_LoggingHeaders))
				$message .= "HEADERS".PHP_EOL.print_r(getallheaders(), true).PHP_EOL;

			if (SettingManager::Get(SettingConfig::$Name_LoggingGet))
				$message .= "GET".PHP_EOL.print_r($_GET, true).PHP_EOL;

			if (SettingManager::Get(SettingConfig::$Name_LoggingPost))
				$message .= "POST".PHP_EOL.print_r($_POST, true);

			if (isset($message))
				SecurityManager::MaskSensitiveData($message);


			LoggingManager::Log(LoggingConfig::$LogType_Info, __FILE__, __CLASS__, __FUNCTION__, __LINE__, LoggingConfig::$Category_InitRequest, $message);
			MvcManager::Process();

			self::End();
		/*}
		catch(Exception $ex)
		{
			self::HandleErrors($ex->getCode(), $ex->getMessage(), $ex->getFile(), $ex->getLine(), $ex->getTrace());
		}*/
	}

	public static function HandleErrors($errorCode, $errorMessage, $errorFile, $errorLine, $stackTrace)
	{
		if (self::$errorHandled == 0)
		{
			self::$errorHandled ++;

            $message = "Error code: ".$errorCode.PHP_EOL."Error message: ".$errorMessage.PHP_EOL."Stack trace".PHP_EOL.print_r($stackTrace, true).PHP_EOL.PHP_EOL."Logged by: ".__FILE__.". Class: ".__CLASS__.". Function: ".__FUNCTION__.". Line: ".__LINE__;
			SecurityManager::MaskSensitiveData($message);

			LoggingManager::Log(LoggingConfig::$LogType_Error, $errorFile, null, null, $errorLine, LoggingConfig::$Category_Error, $message);
			self::End(HttpConfig::$ErrorPageUrl);
			exit();
		}
		else
		{
			HttpResponse::Redirect(HttpConfig::$ErrorPageUrl);
			exit();
		}
	}

	public static function End($redirectUrl = null, $errorCode = null)
	{
		SessionManager::End();
		LoggingManager::End();

		if (isset($redirectUrl))
			HttpResponse::Redirect($redirectUrl);
		else if (isset($errorCode))
			HttpResponse::ReponseWithErrorCode($errorCode);

		exit();
	}
}

HttpHandler::Init();

?>
<?php

class CacheDispatcherThread extends Thread
{
	public $url;
	
	public function __construct($url)
	{
		$this->url = $url;
	}
	
	public function Run()
	{
		$i = 0;
		
		while ($i < 3)
			try
			{
				echo "Sending request to".$this->url."<br/>";
				$result = file_get_contents($this->url);
				echo "Clear cache result from ".$this->url.": ".$result."<br/>";
				break;
			}
			catch(Exception $ex)
			{
				$i++;
			}
	}
	
	
	// public function start()
	// {
		// $this->Run();
	// }
	
	// public function join()
	// {
	// }
}
?>
<?php

class CachingManager
{
	public static function RemoveAll()
	{
		apcu_clear_cache();
	}

	public static function Get($cacheName)
	{
		$val = apcu_fetch($cacheName, $success);

		if ($success)
			return $val;

		return null;
	}

	public static function Remove($cacheName)
	{
		if (count(CachingConfig::$Clients) == 0)
			apcu_delete($cacheName);
		else
		{
			$cacheBaseName = strtok($cacheName, "_");

			if (array_key_exists($cacheBaseName, CachingConfig::$TimeCaches))
			{
				apcu_delete($cacheName);
				return;
			}

			CachingDa::InvalidateCache($cacheName);
		}
	}

	public static function Set($cacheName, $value)
	{
		if (array_key_exists($cacheName, CachingConfig::$TimeCaches))
		{
			apcu_store($cacheName, $value, CachingConfig::$TimeCaches[$cacheName]);
			return;
		}

		$cacheBaseName = strtok($cacheName, "_");

		if (array_key_exists($cacheBaseName, CachingConfig::$TimeCaches))
		{
			apcu_store($cacheName, $value, CachingConfig::$TimeCaches[$cacheBaseName]);
			return;
		}

		apcu_store($cacheName, $value);

		if (count(CachingConfig::$Clients) > 0)
			CachingDa::InvalidateCache($cacheName);
	}
}


?>
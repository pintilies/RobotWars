<?php

class CachingDa extends Da
{
	public static function InvalidateCache($cacheName)
	{
		self::Connect();
		self::InsertOrUpdate("Caching", array("Name" => $cacheName, "IsExpired" => true, "ExpirationDate" => DateTimeManager::GetUtcNow()), array("IsExpired", "ExpirationDate"));
		self::Disconnect();
	}
	
	public static function GetExpiredCaches()
	{
		self::Connect();
		$caches = self::Select("select Name from Caching where IsExpired = 1", false, null, true);
		self::Disconnect();
		
		return $caches;
	}
	
	public static function ClearExpiration($caches)
	{
		self::Connect();
		$caches = self::Update("Caching", array("Name"), array("Name"=> $caches, "IsExpired" => false, "ResetDate" => DateTimeManager::GetUtcNow()));
		self::Disconnect();
	}
}
?>
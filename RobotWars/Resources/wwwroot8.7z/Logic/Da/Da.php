<?php

class Da
{
	public static $MainDB = 0;
	public static $LogDB = 1;

	public static $DbLink;

	public static function SqlValue($val)
	{
		if (!isset($val))
			return 'NULL';

		switch (gettype($val))
		{
			case "boolean":
				return $val ? "1" : "0";
			case "double":
			case "integer":
				return strval($val);
			case "object":
				if ($val instanceof DateTime)
					return "'".$val->format('Y-m-d H:i:s')."'";
		}

		return "'".mysqli_real_escape_string(self::$DbLink, strval($val))."'";
	}

	public static function SqlEscape($val)
	{
		return mysqli_real_escape_string(self::$DbLink, strval($val));
	}


	public static function Connect($dbName = null)
	{
		if ($dbName == null || $dbName == self::$MainDB)
		{
			self::$DbLink = mysqli_connect(MySqlConfig::$Host, MySqlConfig::$Username, MySqlConfig::$Password);

			mysqli_select_db(self::$DbLink, MySqlConfig::$MainDB);
		}
		else if ($dbName == self::$LogDB)
		{
			self::$DbLink = mysqli_connect(MySqlConfig::$Host, MySqlConfig::$Username, MySqlConfig::$Password);

			mysqli_select_db(self::$DbLink, MySqlConfig::$LogDB);
		}
	}

	public static function Query($query, $returnIdentity = false)
	{
		mysqli_query(self::$DbLink, $query);

		if ($returnIdentity)
			return mysqli_insert_id(self::$DbLink);
	}

	public static function Update($table, $keys, $values)
	{
		$query = "update ".$table." set ".implode(",", array_map(function($key) use ($values){return "`".$key."`=".self::SqlValue($values[$key]);}, array_filter(array_keys($values), function($key) use ($keys){return !in_array($key, $keys);})));
		$query .=" where ".implode(" and ", array_map(function ($key) use($values){ return (is_array($values[$key])) ? "`".$key."` in (".implode(",", array_map(array("self", "SqlValue"), $values[$key])).")" : "`".$key."`=".self::SqlValue($values[$key]);}, $keys));

		mysqli_query(self::$DbLink, $query);
	}

	public static function Insert($table, $values)
	{
		$query = "insert into ".$table."(`".implode("`,`", array_keys($values))."`) values (".implode(",", array_map(array("self", "SqlValue"), array_values($values))).")";

		mysqli_query(self::$DbLink, $query);

		return mysqli_insert_id(self::$DbLink);
	}

	public static function InsertOrUpdate($table, $values, $updateValues)
	{
		$query = "insert into ".$table."(`".implode("`,`", array_keys($values))."`) values (".implode(",", array_map(array("self", "SqlValue"), array_values($values))).")";
		$query .= "on duplicate key update ".implode(",", array_map(function($val){return "`".$val."` = values(`".$val."`)";}, $updateValues));

		mysqli_query(self::$DbLink, $query);

		return mysqli_insert_id(self::$DbLink);
	}

	public static function Select($query, $directSql = false, $key = null, $singleArray = false, $onlyFirst = false)
	{
		if ($directSql)
			return mysqli_query(self::$DbLink, $query);

		$result = mysqli_query(self::$DbLink, $query);

		$resultFilter = array();

		while ($row = mysqli_fetch_assoc($result))
		{
			if ($onlyFirst)
				return $row[key($row)];
			
			if (isset($key))
				$resultFilter[$row[$key]] = $row;
			else if ($singleArray)
			{
				foreach($row as $val)
					$resultFilter[] = $val;
			}
			else
				$resultFilter[] = $row;
		}

		return $resultFilter;
	}

	public static function Disconnect()
	{
		mysqli_close(self::$DbLink);
	}
}

?>
<?php

class LoggingDa extends Da
{
	public static function GetNextLoggingSessionIndex($maxValue)
	{
		self::Connect();
		$id = self::Query("update Settings set IntValue=case when IntValue >= ".self::SqlValue($maxValue)." then  last_insert_id(1) else last_insert_id(IntValue + 1) end where Name=".self::SqlValue(SettingConfig::$Name_LoggingSessionIndex), true);
		self::Disconnect();

		return $id;
	}

	public static function InsertLogs($logs, $table)
	{
		$insert = "insert into `".$table."`(`IdSession`,`IdRequest`,`IdSequence`,`InsertDate`,`Url`,`UserId`,`Type`,`Category`,`Application`,`FileName`,`Class`,`Function`,`Line`,`Message`,`Ip`,`Host`,`UserAgent`,`Machine`)values";

		$values = "";
		$i = 0;

		self::Connect();

		foreach($logs as $log)
		{
			if ($i > 0)
				$values .= ",";

			$values .= "(";
			$isFirstColumn = true;

			foreach ($log as $val)
			{
				if ($isFirstColumn)
				{
					$values .= self::SqlValue($val);
					$isFirstColumn = false;
				}
				else
					$values .= ",".self::SqlValue($val);
			}

			$values .= ")";

			$i++;

			if ($i >= 100)
			{
				self::Query($insert.$values);
				$values = "";
				$i = 0;
			}
		}

		if ($i > 0)
			self::Query($insert.$values);

		self::Disconnect();
	}
}

?>
<?php

class ResourceDa extends Da
{
	public static function Get($idResource, $languageCode, $defaultLanguageCode)
	{
		$value = null;
		
		self::Connect();
		$result = self::Select("select Value, UseLanguage from Resources where Id = ".self::SqlValue($idResource)." and Language = ".self::SqlValue($languageCode), false, null, true);
		
		if (count($result) == 0)
		{
			$result = self::Select("select Value from Resources where Id = ".self::SqlValue($idResource)." and Language = ".self::SqlValue($defaultLanguageCode), false, null, true);
		
			if (count($result) > 0)
				$value = $result[0];
		}
		else if (isset($result[1]))
		{
			$result = self::Select("select Value from Resources where Id = ".self::SqlValue($idResource)." and Language = ".self::SqlValue($result[1]), false, null, true);
		
			if (count($result) > 0)
				$value = $result[0];
			else
			{
				$result = self::Select("select Value from Resources where Id = ".self::SqlValue($idResource)." and Language = ".self::SqlValue($defaultLanguageCode), false, null, true);
			
				if (count($result) > 0)
					$value = $result[0];
			}
		}
		else
			$value = $result[0];
		
		self::Disconnect();
		
		return $value;
	}
	
	public static function GetLanguages($onlyEnabled = false)
	{
		self::Connect();
		if ($onlyEnabled)
			$result = self::Select("select Language from Languages where IsEnabled = 1", false, null, true);
		else
			$result = self::Select("select * from Languages", false, "Language");
		self::Disconnect();
		
		return $result;
	}
}

?>
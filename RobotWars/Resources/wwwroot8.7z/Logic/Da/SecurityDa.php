<?php

class SecurityDa extends Da
{
	public static function GetRights($application, $action)
	{
		self::Connect();
		$rights = self::Select("select * from Rights where Action = ".self::SqlValue($action)." and Application = ".self::SqlValue($application));
		self::Disconnect();

		return $rights;
	}

	public static function GetUserTypes()
	{
		self::Connect();
		$userTypes = self::Select("select * from UserTypes", false, "Id");
		self::Disconnect();

		return $userTypes;
	}

	public static function UpdateUserType($userTypeId, $name, $included)
	{
		self::Connect();
		$userTypes = self::Query('update UserTypes set Name = '.self::SqlValue($name).', Included = '.self::SqlValue($included).' where Id = '.self::SqlValue($userTypeId));
		self::Disconnect();

		return $userTypes;
	}

	public static function InsertUserType($name, $included)
	{
		self::Connect();
		$userTypes = self::Query('insert into UserTypes(Name, Included)values('.self::SqlValue($name).','.self::SqlValue($included).')');
		self::Disconnect();

		return $userTypes;
	}

	public static function GetOverAllRequestCount($table, $fromDate, $excludeHosts)
	{
		self::Connect();

		$likeCond = array();

		if (count($excludeHosts) > 0)
		{
			foreach ($excludeHosts as $host => $val)
			{
				$likeCond[] = "`Host` like '%".self::SqlEscape($host)."'";
			}
		}

		if (count($likeCond) > 0)
			$likeCond = " and not (".implode(" or ", $likeCond).")";
		else
			$likeCond  = "";

		$count = self::Select("select count(*) from `".$table."` where IdRequest = 1 and IdSequence = 1 and InsertDate >= ".self::SqlValue($fromDate).$likeCond,false, null, false, true);
		self::Disconnect();

		return $count;
	}

	public static function GetRequestByIpOverLimit($table, $fromDate, $limit, $exeptHosts)
	{
		self::Connect();

		$likeCond = array();

		if (count($exeptHosts) > 0)
		{
			foreach ($exeptHosts as $host)
			{
				$likeCond[] = "`Host` like '%".self::SqlEscape($host)."'";
			}
		}

		if (count($likeCond) > 0)
			$likeCond = " and not (".implode(" and ", $likeCond).")";
		else
			$likeCond  = "";

		$ips = self::Select("select Ip, count(*) N from `".$table."` where IdRequest = 1 and IdSequence = 1 and InsertDate >= ".self::SqlValue($fromDate).$likeCond." group by Ip having N >= ".self::SqlEscape($limit));
		self::Disconnect();

		return $ips;
	}

	public static function SearchRights($action, $startIndex, $maxRows, &$totalRows)
	{
		self::Connect();

		if (empty($action))
			$query = 'select SQL_CALC_FOUND_ROWS * from Rights order by Application, Action limit '.self::SqlValue($startIndex).', '.self::SqlValue($maxRows);
		else
			$query = 'select SQL_CALC_FOUND_ROWS * from Rights where Action like \'%'.self::SqlEscape($action).'%\' or Application like \'%'.self::SqlEscape($action).'%\' order by Application, Action limit '.self::SqlValue($startIndex).', '.self::SqlValue($maxRows);

		$rows = self::Select($query);

		$totalRows = self::Select('SELECT FOUND_ROWS()', false, null, false, true);

		self::Disconnect();

		return $rows;
	}

	public static function UpdateRight($currentApplication, $currentAction, $application, $action, $userTypes, $allowedIps, $deniedIps, $allowedUserIds, $deniedUserIds)
	{
		self::Connect();
		self::Query('update Rights set Application = '.self::SqlValue($application).',Action='.self::SqlValue($action).',UserTypes='.self::SqlValue($userTypes).',AllowedIps='.self::SqlValue($allowedIps).',DeniedIps='.self::SqlValue($deniedIps).',AllowedUserIds='.self::SqlValue($allowedUserIds).',DeniedUserIds='.self::SqlValue($deniedUserIds).' where Application = '.self::SqlValue($currentApplication).' and Action = '.self::SqlValue($currentAction));

		self::Disconnect();
	}

	public static function InsertRight($application, $action, $userTypes, $allowedIps, $deniedIps, $allowedUserIds, $deniedUserIds)
	{
		self::Connect();
		self::Query('insert into Rights(Application,Action,UserTypes,AllowedIps,DeniedIps,AllowedUserIds,DeniedUserIds)values('
			.self::SqlValue($application).','.self::SqlValue($action).','.self::SqlValue($userTypes).','.self::SqlValue($allowedIps).','.self::SqlValue($deniedIps).','.self::SqlValue($allowedUserIds).','.self::SqlValue($deniedUserIds).')');

		self::Disconnect();
	}

	public static function DeleteRight($application, $action)
	{
		self::Connect();
		self::Query('delete from Rights where Application = '.self::SqlValue($application).' and Action = '.self::SqlValue($action));

		self::Disconnect();
	}
}
?>
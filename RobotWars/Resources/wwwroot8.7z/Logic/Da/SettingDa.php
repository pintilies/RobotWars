<?php

class SettingDa extends Da
{
	public static function Get($name, &$type)
	{
		self::Connect();
		$data = self::Select("select * from Settings where Name = ".self::SqlValue($name));
		self::Disconnect();

		if (count($data) == 0)
			return null;

		$data = $data[0];

		$type = $data["ValueType"];

		switch($type)
		{
			case SettingConfig::$Type_Boolean:
			case SettingConfig::$Type_Integer:
				return $data["IntValue"];
			case SettingConfig::$Type_Decimal:
				return $data["DecimalValue"];
			case SettingConfig::$Type_DateTime:
				return $data["DateTimeValue"];
			default:
				return $data["StringValue"];
		}
	}

	public static function Set($name, $value, $type)
	{
		self::Connect();

		switch($type)
		{
			case SettingConfig::$Type_Integer:
			case SettingConfig::$Type_Boolean:
				$sqlField = "IntValue";
				break;
			case SettingConfig::$Type_DateTime:
				$sqlField = "DateTimeValue";
				break;
			case SettingConfig::$Type_Decimal:
				$sqlField = "DecimalValue";
				break;
			default:
				$sqlField = "StringValue";
				break;
		}

		self::Query("update Settings set `".$sqlField."` = ".self::SqlValue($value)." where Name = ".self::SqlValue($name));

		self::Disconnect();
	}
}
?>
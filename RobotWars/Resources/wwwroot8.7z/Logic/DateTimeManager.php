<?php

class DateTimeManager
{
	public static function GetUtcNow()
	{
		return new DateTime(null, new DateTimeZone("UTC"));
	}
}

?>
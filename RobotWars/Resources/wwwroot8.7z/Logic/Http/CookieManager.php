<?php

class CookieManager
{

}

?>
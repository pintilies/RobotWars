<?php
class HtmlManager
{
	public static function AddPaging($url, $pageSize, $pageShown, $currentPage, $itemCount, $fastScrollLeftString, $leftScrollString, $rightScrollString, $fastScrollRightString)
	{
		$placeHolder = urlencode('$$$page$$$');
		$maxPage = $itemCount == 0 ? 0 : intdiv($itemCount - 1, $pageSize);
		if ($currentPage > $maxPage)
			$currentPage = $maxPage + 1;

?>
<div class="paggingContainer">
	<?php if ($currentPage - $pageShown >= 0) {?>
	<a href="<?=str_replace($placeHolder, ($currentPage - $pageShown), $url)?>" class="paggingFastLeft"><?=htmlspecialchars($fastScrollLeftString)?></a>
	<?php }?>
	<?php if ($currentPage > 0) {?>
	<a href="<?=str_replace($placeHolder, ($currentPage - 1), $url)?>" class="paggingLeft"><?=htmlspecialchars($leftScrollString)?></a>
	<?php }?>
	<?php for ($page = $currentPage - $pageShown; $page < $currentPage; $page++) if ($page >= 0) {?>
	<a href="<?=str_replace($placeHolder, $page, $url)?>" class="paggingLeft"><?=$page + 1?></a>
	<?php }?>
	<?php if ($maxPage > 0 && $currentPage <= $maxPage) {?>
	<div class="paggingCurrent"><?=$currentPage + 1?></div>
	<?php }?>
	<?php for ($page = $currentPage + 1; $page <= $maxPage && $page <= $currentPage + $pageShown; $page++) {?>
	<a href="<?=str_replace($placeHolder, $page, $url)?>" class="paggingRight"><?=$page + 1?></a>
	<?php }?>
	<?php if ($currentPage < $maxPage) {?>
	<a href="<?=str_replace($placeHolder, $currentPage + 1, $url)?>" class="paggingLeft"><?=htmlspecialchars($rightScrollString)?></a>
	<?php }?>
	<?php if ($currentPage + $pageShown <= $maxPage) {?>
	<a href="<?=str_replace($placeHolder, ($currentPage + $pageShown), $url)?>" class="paggingFastRight"><?=htmlspecialchars($fastScrollRightString)?></a>
	<?php }?>
</div>
<?php
	}

	public static function Done($message)
	{
?>
<div class="done">
	<img src="<?=ResourceManager::Get(33)?>" />
	<span>
		<?=$message?>
	</span>
</div>
<?php
	}

	public static function Errors($errorCodes)
	{
		if (count($errorCodes) == 0)
			return;
?>
<ul class="errorList">
<?php
		foreach ($errorCodes as $errorCode)
		{
?>
	<li><?=ResourceManager::Get($errorCode)?></li>
<?php			
		}
?>
</ul>
<?php
	}

	public static function InvalidField($invalidFields, $field)
	{
		if (!array_key_exists($field, $invalidFields))
			return;
?>
<div class="errorField"><?=ResourceManager::Get($invalidFields[$field])?></div>
<?php
	}

	public static function HighlightFieldError($invalidFields)
	{
		if (count($invalidFields) == 0)
			return;

		$fieldsJscript = "var fields = [";
		$i = 0;

		foreach ($invalidFields as $key => $value)
		{
			$fieldsJscript.= ($i++ > 0 ? ',' : '').'"#'.$key.'"';
		}

		$fieldsJscript .= "];";
		
?>
<script>
	$(document).ready(function () {
		<?=$fieldsJscript?>

		for (var i = 0; i < fields.length; i++)
		{
			if ($(fiels[i]).length)
				$(fiels[i]).toggleClass("error");
		}
	});
</script>
<?php
	}
}
?>
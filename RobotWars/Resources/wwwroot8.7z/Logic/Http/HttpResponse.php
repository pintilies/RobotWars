<?php

class HttpResponse
{
	public static function Redirect($url)
	{
		if (strpos($url, "http") == 0)
		{
			header('Location: '.$url);
			exit();
		}

		$baseUrl = (ServerConfig::$HttpsCall ? "https://" : "http://").ServerConfig::$ServerName;

		header('Location: '.$baseUrl.$url);
		exit();
	}

	public static function GetUrl($controller = null, $action = null, $extraParam = null, $extraQueryStringParameters = null, $secure = false, $application = null)
	{
		$uri = "";

		if (ResourceManager::$Language != ResourceConfig::$DefaultLanguage)
			$uri .= "/".ResourceManager::$Language;

		if (isset($extraParam) || isset($controller))
		{
			$uri .= "/".(isset($controller) ? $controller : MvcConfig::$DefaultController);
		}

		if (isset($extraParam) || isset($action))
		{
			$uri .= "/".(isset($action) ? $action : MvcConfig::$DefaultAction);
		}

		if (isset($extraParam))
			foreach($extraParam as $param)
				$uri .= "/".urlencode($param);

		if (isset($extraQueryStringParameters))
		{
			$uri .= "?";
			$i = 0;

			foreach($extraQueryStringParameters as $key => $val)
				$uri .= ($i++ > 0 ? "&" : "").$key."=".urlencode($val);
		}

		if (isset($application))
			return ($secure ? "https://" : "http://").ServerConfig::$ApplicationDomains[$application].$uri;

		if ($secure && !ServerConfig::$HttpsCall)
			return "https://".ServerConfig::$ServerName.$uri;

		return empty($uri) ? "/" : $uri;
	}

	public static function GetCurrentUrl($secure = false)
	{
		if ($secure && !ServerConfig::$HttpsCall)
			return "https://".ServerConfig::$ServerName.ServerConfig::$RequestUri;

		return ServerConfig::$RequestUri;
	}

	public static function AppendQueryString($url, $params)
	{
		if (count($params) == 0)
			return "";

		$appendAnd = true;

		if (strpos('?', $url) === false)
		{
			$url .= '?';
			$appendAnd = false;
		}

		foreach ($params as $key->$value)
		{
			if (!$appendAnd)
			{
				$appendAnd = true;
			}
			else
				$uri .= "&";

			$uri .=  $key."=".urlencode($value);
		}

		return $uri;
	}

	public static function ReponseWithErrorCode($errorCode)
	{
		http_response_code($errorCode);
	}

	public static function SetContentType($contentType)
	{
		header('Content-Type'.$contentType);
	}
}

?>
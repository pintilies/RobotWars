<?php

class MvConnectParams
{
	public static $Response;
	public static $Layout;
	public static $Title;
	public static $Meta;

	public static function Init()
	{
		self::$Response = null;
		self::$Layout = null;
		self::$Title = array();
		self::$Meta = array();
	}
}

?>
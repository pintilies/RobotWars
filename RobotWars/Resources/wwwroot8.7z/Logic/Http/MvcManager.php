<?php

class MvcManager
{
	public static $Controller = null;
	public static $Action = null;
	public static $Response = null;
	public static $MethodParams = array();
	public static $HasValidator =false;
	public static $SubActionController = null;
	public static $SubActionAction = null;
	public static $SubActionMethodParams = array();
	public static $SubActionHasValidator = false;

	public static function Process()
	{
		//LoggingManager::StartTimer();
		self::ParseRequest();
		//LoggingManager::EndTimer();

		if (isset(self::$SubActionController))
		{
			MvcModel::Init();

			if (self::$SubActionHasValidator)
				call_user_func_array(array(self::$SubActionController."Validator", self::$SubActionAction), self::$SubActionMethodParams);

			call_user_func_array(array(self::$SubActionController."HttpService", self::$SubActionAction), self::$SubActionMethodParams);

			if (MvcModel::$Result == MvcConfig::$ModelResult_Redirect)
				HttpHandler::End(MvcModel::$Data);

			if (MvcModel::$Result == MvcConfig::$ModelResult_Html)
			{
				echo MvcModel::$Data;
				HttpHandler::End();
			}

			if (MvcModel::$Result == MvcConfig::$ModelResult_OtherType)
			{
				HttpResponse::SetContentType(MvcModel::$ContentType);
				echo MvcModel::$Data;
				HttpHandler::End();
			}

			if (MvcModel::$Result == MvcConfig::$ModelResult_ErrorCode)
			{
				HttpHandler::End(null, MvcModel::$Data);
			}

			MvcModel::SaveAsSubAction();

		}

		MvcModel::Init();

		if (self::$HasValidator)
			call_user_func_array(array(self::$Controller."Validator", self::$Action), self::$MethodParams);

		call_user_func_array(array(self::$Controller."HttpService", self::$Action), self::$MethodParams);

		if (MvcModel::$Result == MvcConfig::$ModelResult_Redirect)
			HttpHandler::End(MvcModel::$Data);

		if (MvcModel::$Result == MvcConfig::$ModelResult_Html)
		{
			echo MvcModel::$Data;
			HttpHandler::End();
		}

		if (MvcModel::$Result == MvcConfig::$ModelResult_OtherType)
		{
			HttpResponse::SetContentType(MvcModel::$ContentType);
			echo MvcModel::$Data;
			HttpHandler::End();
		}

		if (MvcModel::$Result == MvcConfig::$ModelResult_ErrorCode)
		{
			HttpHandler::End(null, MvcModel::$Data);
		}

		MvcModel::SaveAsMainAction();
		MvConnectParams::Init();

		include MvcConfig::$MvConnector;
		MvConnector::Bridge(self::$Controller, self::$Action);
		self::$Response = MvConnectParams::$Response;
		include MvcConfig::$HttpServiceRoot.MvcConfig::$LayoutRoot.MvConnectParams::$Layout."Layout.php";
	}

	public static function RenderPartial($controller, $action, $params = null)
	{
		if ($controller == self::$SubActionController && $action == self::$SubActionAction)
		{
			MvcModel::RestoreFromSubAction();

			MvConnectParams::Init();
			MvConnector::Bridge(self::$SubActionController, self::$SubActionAction);
			include MvcConfig::$HttpServiceRoot."/".self::$SubActionController."/".MvConnectParams::$Response."Response.php";
		}
		else
		{
			MvcModel::Init();

			if (method_exists($controller."HttpService", $action))
			{
				call_user_func_array(array($controller."HttpService", $action), $params ?? array());
			}
			else
			{
				$controllerPath = MvcConfig::$HttpServiceRoot."/".$controller."/".$controller."HttpService.php";

				if (file_exists($controllerPath))
				{
					include $controllerPath;

					if (method_exists($controller."HttpService", $action))
					{
						call_user_func_array(array($controller."HttpService", $action), $params ?? array());
					}
				}
			}

			if (MvcModel::$Result == MvcConfig::$ModelResult_Redirect)
				throw new Exception("Redirection at this point not possible! Controller: ".$controller.", Action: ".$action);

			if (MvcModel::$Result == MvcConfig::$ModelResult_Html)
				throw new Exception("Row html at this point not possible! Controller: ".$controller.", Action: ".$action);

			if (MvcModel::$Result == MvcConfig::$ModelResult_OtherType)
				throw new Exception("Other type of response at this point not possible! Controller: ".$controller.", Action: ".$action);

			if (MvcModel::$Result == MvcConfig::$ModelResult_ErrorCode)
				throw new Exception("Error code at this point not possible! Controller: ".$controller.", Action: ".$action);

			MvConnectParams::Init();
			MvConnector::Bridge($controller, $action);

			include MvcConfig::$HttpServiceRoot."/".$controller."/".MvConnectParams::$Response."Response.php";
		}
	}

	public static function RenderBody()
	{
		MvcModel::RestoreFromMainAction();
		include MvcConfig::$HttpServiceRoot."/".self::$Controller."/".self::$Response."Response.php";
	}

	public static function ParseRequest()
	{
		$url = str_split(ServerConfig::$RequestPath);
		$char = next($url);

		if ($char === false)
			self::$Controller = MvcConfig::$DefaultController;
		else
		{
			if ($char == '/')
			{
				LoggingManager::Log(LoggingConfig::$LogType_Info, __FILE__, __CLASS__, __FUNCTION__, __LINE__, LoggingConfig::$Category_InvalidUrl, "Empty controller name");
				HttpHandler::End(null, 404);
			}

			$isLanguage = false;

			while ($char !== false && $char != '/')
			{
				if (($char >= 'a' && $char < 'z') || ($char >= 'A' && $char < 'Z') || ($char >= '0' && $char < '9') || $char == '-')
				{
					self::$Controller .= $char;

					if ($char == '-')
					{
						$isLanguage = true;
					}
				}
				else
				{
					LoggingManager::Log(LoggingConfig::$LogType_Info, __FILE__, __CLASS__, __FUNCTION__, __LINE__, LoggingConfig::$Category_InvalidUrl, "Controller char invalid: ".$char);
					HttpHandler::End(null, 404);
				}

				$char = next($url);

				if ($char === false || $char == '/')
				{
					if (array_key_exists(self::$Controller, ResourceManager::GetEnabledLanguages()))
					{
						UserManager::SetLanguage(self::$Controller);
						ResourceManager::$Language = self::$Controller;
						$isLanguage = false;
						self::$Controller = null;
						$char = next($url);
					}
					else if ($isLanguage)
					{
						LoggingManager::Log(LoggingConfig::$LogType_Info, __FILE__, __CLASS__, __FUNCTION__, __LINE__, LoggingConfig::$Category_InvalidUrl, "Language not found: ".self::$Controller);
						HttpHandler::End(null, 404);
					}
				}

			}

			if (!isset(self::$Controller))
				self::$Controller = MvcConfig::$DefaultController;
			else
				$char = next($url);
		}

		if ($char == '/')
		{
			LoggingManager::Log(LoggingConfig::$LogType_Info, __FILE__, __CLASS__, __FUNCTION__, __LINE__, LoggingConfig::$Category_InvalidUrl, "Empty action name");
			HttpHandler::End(null, 404);
		}

		while ($char !== false && $char != '/')
		{
			if (($char >= 'a' && $char < 'z') || ($char >= 'A' && $char < 'Z')|| ($char >= '0' && $char < '9'))
				self::$Action .= $char;
			else
			{
				LoggingManager::Log(LoggingConfig::$LogType_Info, __FILE__, __CLASS__, __FUNCTION__, __LINE__, LoggingConfig::$Category_InvalidUrl, "Action char invalid: ".$char);
				HttpHandler::End(null, 404);
			}

			$char = next($url);
		}

		if (!isset(self::$Action))
			self::$Action = MvcConfig::$DefaultAction;
		else
			$char = next($url);

		$actionInfo = CachingManager::Get(CachingConfig::$CacheBaseName_Mvc.ServerConfig::$Application.'_'.self::$Controller.'_'.self::$Action);

		if (!isset($actionInfo))
		{
			$controllerPath = MvcConfig::$HttpServiceRoot."/".self::$Controller."/".self::$Controller."HttpService.php";

			if (!file_exists($controllerPath))
			{
				LoggingManager::Log(LoggingConfig::$LogType_Info, __FILE__, __CLASS__, __FUNCTION__, __LINE__, LoggingConfig::$Category_InvalidUrl, "Invalid controller: ".self::$Controller);
				HttpHandler::End(null, 404);
			}

			include $controllerPath;

			if (!method_exists(self::$Controller."HttpService", self::$Action))
			{
				LoggingManager::Log(LoggingConfig::$LogType_Info, __FILE__, __CLASS__, __FUNCTION__, __LINE__, LoggingConfig::$Category_InvalidUrl, "Invalid action: ".self::$Controller.".".self::$Action);
				HttpHandler::End(null, 404);
			}

			$validatorPath = MvcConfig::$HttpServiceRoot."/".self::$Controller."/".self::$Controller."Validator.php";

			if (file_exists($validatorPath))
			{
				include $validatorPath;

				if (method_exists(self::$Controller."Validator", self::$Action))
				{
					self::$HasValidator = true;
					$class = new ReflectionClass(self::$Controller."Validator");
					$method = $class->getMethod(self::$Action);
				}
			}

			$actionInfoPn = array();
			$actionInfoPv = array();

			if (!self::$HasValidator)
			{
				$class = new ReflectionClass(self::$Controller."HttpService");
				$method = $class->getMethod(self::$Action);
			}

			foreach($method->getParameters() AS $param)
			{
				$actionInfoPn[] = $param->getName();
				$actionInfoPv[] = $param->isDefaultValueAvailable() ? $param->getDefaultValue() : null;
			}

			$actionInfo = array($actionInfoPn, $actionInfoPv, self::$HasValidator);

			CachingManager::Set(CachingConfig::$CacheBaseName_Mvc.ServerConfig::$Application.'_'.self::$Controller."_".self::$Action, $actionInfo);
			SecurityManager::CheckRightsWithRedirection(self::$Controller."/".self::$Action);
		}
		else
		{
			SecurityManager::CheckRightsWithRedirection(self::$Controller."/".self::$Action);

			if ($actionInfo[2])
			{
				include MvcConfig::$HttpServiceRoot."/".self::$Controller."/".self::$Controller."Validator.php";
				self::$HasValidator = true;
			}

			include MvcConfig::$HttpServiceRoot."/".self::$Controller."/".self::$Controller."HttpService.php";
		}

		$immParams = array();
		$lastParameter = "";
		$requestParamCount = 0;

		while($char !== false && $requestParamCount <= 15)
		{
			if ($char == '/')
			{
				$immParams[] = $lastParameter;
				$requestParamCount++;
				$lastParameter = "";
			}
			else
				$lastParameter .= $char;

			$char = next($url);
		}

		if ($lastParameter != "")
		{
			$immParams[] = $lastParameter;
			$requestParamCount++;
		}

		$actionInfoPn = $actionInfo[0];
		$actionInfoPv = $actionInfo[1];
		$methodParamCount = count($actionInfoPn);

		for($i = 0; $i < $methodParamCount; $i++)
		{
			if ($requestParamCount > $i)
				${"value$i"} = urldecode($immParams[$i]);
			else
			{
				$paramName = $actionInfoPn[$i];

				if (isset($_GET[$paramName]))
					${"value$i"} = $_GET[$paramName];
				else if (isset($_POST[$paramName]))
					${"value$i"} = $_POST[$paramName];
				else
					${"value$i"} = $actionInfoPv[$i];
			}

			self::$MethodParams[] = &${"value$i"};
		}

		if (isset($_GET[MvcConfig::$SubActionPrefix]) || isset($_POST[MvcConfig::$SubActionPrefix]))
		{
			$url = isset($_GET[MvcConfig::$SubActionPrefix]) ? str_split($_GET[MvcConfig::$SubActionPrefix]) : strl_split($_POST[MvcConfig::$SubActionPrefix]);
			$char = current($url);

			if ($char !== false)
			{
				if ($char == '/')
				{
					$char = next($url);
					self::$SubActionController = "";

					if ($char !== false && $char != '/')
					{
						while ($char !== false && $char != '/')
						{
							if (($char >= 'a' && $char < 'z') || ($char >= 'A' && $char < 'Z')|| ($char >= '0' && $char < '9'))
								self::$SubActionController .= $char;
							else
							{
								LoggingManager::Log(LoggingConfig::$LogType_Info, __FILE__, __CLASS__, __FUNCTION__, __LINE__, LoggingConfig::$Category_InvalidUrl, "Invalid sub action controller char: ".$char);
								self::$SubActionController = null;
								break;
							}

							$char = next($url);
						}

						$char = next($url);
					}
					else
					{
						LoggingManager::Log(LoggingConfig::$LogType_Info, __FILE__, __CLASS__, __FUNCTION__, __LINE__, LoggingConfig::$Category_InvalidUrl, "Empty sub action controller name");
						self::$SubActionController = null;
					}
				}
				else
				{
					LoggingManager::Log(LoggingConfig::$LogType_Info, __FILE__, __CLASS__, __FUNCTION__, __LINE__, LoggingConfig::$Category_InvalidUrl, "First char invalid: ".$url[$i]);
					self::$SubActionController = null;
				}
			}
			else
				LoggingManager::Log(LoggingConfig::$LogType_Info, __FILE__, __CLASS__, __FUNCTION__, __LINE__, LoggingConfig::$Category_InvalidUrl, "Empty sub action url");

			if (isset(self::$SubActionController))
			{
				if ($char !== false && $char != '/')
				{
					while ($char !== false && $char != '/')
					{
						if (($char >= 'a' && $char < 'z') || ($char >= 'A' && $char < 'Z')|| ($char >= '0' && $char < '9'))
							self::$SubActionAction .= $char;
						else
						{
							LoggingManager::Log(LoggingConfig::$LogType_Info, __FILE__, __CLASS__, __FUNCTION__, __LINE__, LoggingConfig::$Category_InvalidUrl, "Invalid sub action action char: ".$char);
							self::$SubActionController = null;
							break;
						}

						$char = next($url);
					}

					$char = next($url);
				}
				else
				{
					LoggingManager::Log(LoggingConfig::$LogType_Info, __FILE__, __CLASS__, __FUNCTION__, __LINE__, LoggingConfig::$Category_InvalidUrl, "Empty sub action action name");
					self::$SubActionController = null;
				}
			}

			if (isset(self::$SubActionController))
			{
				$actionInfo = CachingManager::Get(CachingConfig::$CacheBaseName_Mvc.ServerConfig::$Application.'_'.self::$SubActionController."_".self::$SubActionAction);

				if (!isset($actionInfo))
				{
					$controllerPath = MvcConfig::$HttpServiceRoot."/".self::$SubActionController."/".self::$SubActionController."HttpService.php";

					if (file_exists($controllerPath))
					{
						include $controllerPath;

						if (method_exists(self::$SubActionController."HttpService", self::$SubActionAction))
						{
							$validatorPath = MvcConfig::$HttpServiceRoot."/".self::$SubActionController."/".self::$SubActionAction."Validator.php";

							if (fileExists($validatorPath))
							{
								include $validatorPath;

								if (method_exists(self::$Controller."Validator", self::$Action))
								{
									self::$SubActionHasValidator = true;
									$class = new ReflectionClass(self::$SubActionController."Validator");
									$method = $class->getMethod(self::$SubActionAction);
								}
							}

							$actionInfoPn = array();
							$actionInfoPv = array();

							if (!self::$SubActionHasValidator)
							{
								$class = new ReflectionClass(self::$SubActionController."HttpService");
								$method = $class->getMethod(self::$SubActionAction);
							}

							foreach($method->getParameters() AS $param)
							{
								$actionInfoPn[] = $param->getName();
								$actionInfoPv[] = $param->isDefaultValueAvailable() ? $param->getDefaultValue() : null;
							}

							$actionInfo = array($actionInfoPn, $actionInfoPv, self::$SubActionHasValidator);

							CachingManager::Set(CachingConfig::$CacheBaseName_Mvc.ServerConfig::$Application.'_'.self::$SubActionController."_".self::$SubActionAction, $actionInfo);
							SecurityManager::CheckRightsWithRedirection(self::$SubActionController."/".self::$SubActionAction);
						}
						else
						{
							LoggingManager::Log(LoggingConfig::$LogType_Info, __FILE__, __CLASS__, __FUNCTION__, __LINE__, LoggingConfig::$Category_InvalidUrl, "Invalid sub action controller: ".self::$SubActionController);
							self::$SubActionController = null;
						}
					}
					else
					{
						LoggingManager::Log(LoggingConfig::$LogType_Info, __FILE__, __CLASS__, __FUNCTION__, __LINE__, LoggingConfig::$Category_InvalidUrl, "Invalid sub action controller: ".self::$SubActionController);
						self::$SubActionController = null;
					}
				}
				else
				{
					SecurityManager::CheckRightsWithRedirection(self::$SubActionController."/".self::$SubActionAction);

					if ($actionInfo[2])
					{
						include MvcConfig::$HttpServiceRoot."/".self::$SubActionController."/".self::$SubActionController."Validator.php";
						self::$SubActionHasValidator = true;
					}

					include MvcConfig::$HttpServiceRoot."/".self::$SubActionController."/".self::$SubActionController."HttpService.php";
				}
			}

			if (isset(self::$SubActionController))
			{
				$immParams = array();
				$lastParameter = "";
				$requestParamCount = 0;

				while($char !== false && $requestParamCount <= 15)
				{
					if ($char == '?')
					{
						LoggingManager::Log(LoggingConfig::$LogType_Info, __FILE__, __CLASS__, __FUNCTION__, __LINE__, LoggingConfig::$Category_InvalidUrl, "Invalid querystring char '?' found in subaction url");
						self::$SubActionController = null;
						return;
					}
					else if ($char == '/')
					{
						$immParams[] = $lastParameter;
						$requestParamCount++;
						$lastParameter = "";
					}
					else
						$lastParameter .= $char;

					$char = next($url);
				}

				if ($lastParameter != "")
				{
					$immParams[] = $lastParameter;
					$requestParamCount++;
				}

				$actionInfoPn = $action[0];
				$actionInfoPv = $action[1];
				$methodParamCount = count($actionInfoPn);

				for($i = 0; $i < $methodParamCount; $i++)
				{
					if ($requestParamCount > $i)
						${"value$i"} = urldecode($immParams[$i]);
					else
					{
						$paramName = MvcConfig::$SubActionPrefix.$actionInfoPn[$i];

						if (isset($_GET[$paramName]))
							${"value$i"} = $_GET[$paramName];
						else if (isset($_POST[$paramName]))
							${"value$i"} = $_POST[$paramName];
						else
							${"value$i"} = $actionInfoPv[$i];
					}

					self::$SubActionMethodParams[] = &${"value$i"};
				}
			}
		}
	}
}


?>
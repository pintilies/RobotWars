<?php

class MvcModel
{
	public static $Result;
	public static $ContentType;
	public static $Data;
	public static $Errors;
	public static $InvalidFields;
	public static $Step;

	private static $MainActionResult;
	private static $MainActionData;
	private static $MainActionErrors;
	private static $MainActionInvalidFields;
	private static $MainActionStep;

	private static $SubActionResult;
	private static $SubActionData;
	private static $SubActionErrors;
	private static $SubActionInvalidFields;
	private static $SubActionStep;

	public static function Init()
	{
		self::$Result = MvcConfig::$ModelResult_Response;
		self::$Data = null;
		self::$Errors = array();
		self::$InvalidFields = array();
		self::$Step = 0;
	}

	public static function IsValid()
	{
		return count(self::$Errors) == 0 && count(self::$InvalidFields) == 0; 
	}

	public static function SaveAsSubAction()
	{
		self::$SubActionResult = self::$Result;
		self::$SubActionData = self::$Data;
		self::$SubActionErrors = self::$Errors;
		self::$SubActionInvalidFields = self::$InvalidFields;
		self::$SubActionStep = self::$Step;
	}

	public static function RestoreFromSubAction()
	{
		self::$Result = self::$SubActionResult;
		self::$Data = self::$SubActionData;
		self::$Errors = self::$SubActionErrors;
		self::$InvalidFields = self::$SubActionInvalidFields;
		self::$Step = self::$SubActionStep;
	}

	public static function SaveAsMainAction()
	{
		self::$MainActionResult = self::$Result;
		self::$MainActionData = self::$Data;
		self::$MainActionErrors = self::$Errors;
		self::$MainActionInvalidFields = self::$InvalidFields;
		self::$MainActionStep = self::$Step;
	}

	public static function RestoreFromMainAction()
	{
		self::$Result = self::$MainActionResult;
		self::$Data = self::$MainActionData;
		self::$Errors = self::$MainActionErrors;
		self::$InvalidFields = self::$MainActionInvalidFields;
		self::$Step = self::$MainActionStep;
	}

}

?>
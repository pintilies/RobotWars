<?php

class SessionManager
{
	public static function Init()
	{
		 session_start();
	}

		
	public static function End()
	{
		session_write_close();
	}
	
	public static function GetOrSetSessionValue($sessionKey, $defaultValue)
	{
		if (isset($_SESSION[$sessionKey]))
		{
			return $_SESSION[$sessionKey];
		}
		
		$_SESSION[$sessionKey] = $defaultValue;
		
		return $defaultValue;
	}
}


?>
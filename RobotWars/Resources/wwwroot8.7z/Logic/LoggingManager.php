<?php

class LoggingManager
{
	public static $IdSession;
	public static $IdRequest;
	public static $IdSequence = 1;
	public static $Logs = array();

	public static $FilterTypes;
	public static $FilterUserIds;
	public static $FilterCategories;

    public static $StartTime;

	public static function Init()
	{
		if (!isset($_SESSION[SessionConfig::$Key_LogId]))
		{
			self::$IdSession = LoggingDa::GetNextLoggingSessionIndex(LoggingConfig::$MaxIdSize);
			$_SESSION[SessionConfig::$Key_LogId] = self::$IdSession;
		}
        else
            self::$IdSession = $_SESSION[SessionConfig::$Key_LogId];

		if (!isset($_SESSION[SessionConfig::$Key_RequestId]))
			self::$IdRequest = 1;
		else
		{
			self::$IdRequest = $_SESSION[SessionConfig::$Key_RequestId] + 1;

			if (self::$IdRequest >= LoggingConfig::$MaxIdSize)
				self::$IdRequest = 1;
		}

		$_SESSION[SessionConfig::$Key_RequestId] = self::$IdRequest;
		self::$FilterTypes = SettingManager::Get(SettingConfig::$Name_LoggingFilterByTypes);
		self::$FilterUserIds = SettingManager::Get(SettingConfig::$Name_LoggingFilterByUserIds);
        self::$FilterCategories = SettingManager::Get(SettingConfig::$Name_LoggingFilterByCategories);
	}

	public static function Log($type, $fileName, $class, $function, $line, $category, $message = null)
	{
		$isLogged = false;

		if (array_key_exists($type, self::$FilterTypes))
			$isLogged = true;
		else if (isset(self::$FilterUserIds) && isset(UserManager::$UserId) && array_key_exists(UserManager::$UserId, self::$FilterUserIds))
			$isLogged = true;
		else if (array_key_exists($category, self::$FilterCategories))
			$isLogged = true;

		if ($isLogged)
		{
			if (!is_string($message))
			{
				$message = strval($message);
			}

			if (self::$IdRequest == 1 && self::$IdSequence == 1)
				self::$Logs[] = array(self::$IdSession,self::$IdRequest,self::$IdSequence++,DateTimeManager::GetUtcNow(),ServerConfig::$RequestPath,
					UserManager::$UserId, $type, $category, LoggingConfig::$Application, substr($fileName, strlen(ServerConfig::$ServerRoot)), $class, $function, $line, $message,
					ServerConfig::$CallerIp, ServerConfig::$CallerHostName, ServerConfig::$UserAgent, LoggingConfig::$Machine);
			else if (self::$IdSequence == 1)
				self::$Logs[] = array(self::$IdSession,self::$IdRequest,self::$IdSequence++,DateTimeManager::GetUtcNow(),ServerConfig::$RequestPath,
					UserManager::$UserId, $type, $category, LoggingConfig::$Application, substr($fileName, strlen(ServerConfig::$ServerRoot)), $class, $function, $line, $message,
					null, null, null, LoggingConfig::$Machine);
			else
				self::$Logs[] = array(self::$IdSession,self::$IdRequest,self::$IdSequence++,DateTimeManager::GetUtcNow(),null,
					UserManager::$UserId, $type, $category, LoggingConfig::$Application, substr($fileName, strlen(ServerConfig::$ServerRoot)), $class, $function, $line, $message,
					null, null, null, LoggingConfig::$Machine);

		}
	}

	public static function Clear()
	{
		self::$Logs = array();
		self::$IdSequence = 1;
	}

	public static function End()
	{
		if (count(self::$Logs) > 0)
			LoggingDa::InsertLogs(self::$Logs, SettingManager::Get(SettingConfig::$Name_LoggingTable));
	}

    public static function StartTimer()
    {
        self::$StartTime = microtime(true);
    }

    public static function EndTimer()
    {
        $endTime = microtime(true);
        echo self::$StartTime - $endTime."<br/>";
    }
}

?>
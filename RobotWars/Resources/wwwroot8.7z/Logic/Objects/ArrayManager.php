<?php

class ArrayManager
{
	public static function ExplodeToInt($separator, $str)
	{
		if (empty($str))
			return array();

		$arr = explode($separator, $str);

		foreach($arr as &$value)
			$value = intval($value);

		return $arr;
	}

	public static function ExplodeAsKeys($separator, $str, $asInt = false)
	{
		if (empty($str))
			return array();

		$arr = explode($separator, $str);
        $arrK = array();

		if ($asInt)
			foreach($arr as $value)
				$arrK[intval($value)] = 1;
		else
			foreach($arr as $value)
				$arrK[$value] = 1;

		return $arrK;
	}

	public static function ExplodeAsKeyValue($separator, $separator2, $str, $keyAsInt = false, $valueAsInt = false)
	{
		if (empty($str))
			return array();

		$arr = explode($separator, $str);
        $arrK = array();

		if ($keyAsInt && $valueAsInt)
			foreach($arr as $value)
			{
				$keyValue = explode($separator2, $value);
				$arrK[intval($keyValue[0])] = intval($keyValue[1]);
			}
		else if ($keyAsInt && !$valueAsInt)
			foreach($arr as $value)
			{
				$keyValue = explode($separator2, $value);
				$arrK[intval($keyValue[0])] = $keyValue[1];
			}
		else if (!$keyAsInt && $valueAsInt)
			foreach($arr as $value)
			{
				$keyValue = explode($separator2, $value);
				$arrK[$keyValue[0]] = intval($keyValue[1]);
			}
		else
			foreach($arr as $value)
			{
				$keyValue = explode($separator2, $value);
				$arrK[$keyValue[0]] = $keyValue[1];
			}

		return $arrK;
	}

	public static function ValuesAsKeys($arr)
	{
		$arrK = array();

		foreach($arr as $value)
			$arrK[$value] = 1;

		return $arrK;
	}

	public static function IsInWildStringArr($val, $arr)
	{
		foreach ($arr as $arrVal)
			if (fnmatch($arrVal, $val))
				return true;

		return false;
	}
}

?>
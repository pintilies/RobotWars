<?php

class NetworkManager
{
	public static function IsStrInWildcharList($ip, $list)
	{
		foreach ($list as $item)
			if (fnmatch($item, $ip))
				return true;


		return false;
	}
}

?>
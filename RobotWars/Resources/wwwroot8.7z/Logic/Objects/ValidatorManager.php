<?php
class ValidatorManager
{
	public static function Int(&$value, $parameterName, $errorCode)
	{
		if (is_int($value) || ctype_digit($value))
		{
			$value = intval($value);
			return true;
		}

		MvcModel::$InvalidFields[$parameterName] = $errorCode;

		return false;
	}

	public static function Decimal(&$value, $parameterName, $errorCode)
	{
		if (is_numeric($value))
		{
			$value = floatval($value);
			return true;
		}

		MvcModel::$InvalidFields[$parameterName] = $errorCode;

		return false;
	}

	public static function Arr(&$value, $parameterName, $errorCode)
	{
		if (!isset($value))
		{
			$value = array();
			return true;
		}

		if (is_array($value))
		{
			return true;
		}

		MvcModel::$InvalidFields[$parameterName] = $errorCode;

		return false;
	}

	public static function ArrValInt(&$value, $parameterName, $errorCode)
	{
		foreach ($value as &$item)
			if (is_int($item) || ctype_digit($item))
				$item = intval($item);
			else
			{
				MvcModel::$InvalidFields[$parameterName] = $errorCode;

				return false;
			}

		return true;
	}

	public static function ArrValInArrKey(&$value, $limitedSet, $parameterName, $errorCode)
	{
		foreach ($value as $item)
			if (!array_key_exists($item, $limitedSet))
			{
				MvcModel::$InvalidFields[$parameterName] = $errorCode;

				return false;
			}

		return true;
	}

	public static function InArrKey(&$value, $arr, $parameterName, $errorCode)
	{
		if (!array_key_exists($value, $arr))
		{
			MvcModel::$InvalidFields[$parameterName] = $errorCode;

			return false;
		}

		return true;
	}

	public static function NotEmp(&$value, $parameterName, $errorCode)
	{
		if (!empty($value))
		{
			return true;
		}

		MvcModel::$InvalidFields[$parameterName] = $errorCode;

		return false;
	}

	public static function NotEmpTrim(&$value, $parameterName, $errorCode)
	{
		$value = trim($value);

		if (!empty($value))
		{
			return true;
		}

		MvcModel::$InvalidFields[$parameterName] = $errorCode;

		return false;
	}

	public static function MinLength(&$value, $minLength, $parameterName, $errorCode)
	{
		if (strlen($value) >= $minLength)
		{
			return true;
		}

		MvcModel::$InvalidFields[$parameterName] = $errorCode;

		return false;
	}

	public static function MaxLength(&$value, $maxLength, $parameterName, $errorCode)
	{
		if (strlen($value) <= $maxLength)
		{
			return true;
		}

		MvcModel::$InvalidFields[$parameterName] = $errorCode;

		return false;
	}

	public static function MinValue(&$value, $minValue, $parameterName, $errorCode)
	{
		if ($value >= $minValue)
		{
			return true;
		}

		MvcModel::$InvalidFields[$parameterName] = $errorCode;

		return false;
	}

	public static function MaxValue(&$value, $maxValue, $parameterName, $errorCode)
	{
		if ($value <= $maxValue)
		{
			return true;
		}

		MvcModel::$InvalidFields[$parameterName] = $errorCode;

		return false;
	}

	public static function Email(&$value, $parameterName, $errorCode)
	{
		if (filter_var($value, FILTER_VALIDATE_EMAIL))
		{
			return true;
		}

		MvcModel::$InvalidFields[$parameterName] = $errorCode;

		return false;
	}

	public static function Ip(&$value, $parameterName, $errorCode)
	{
		if (filter_var($value, FILTER_VALIDATE_IP))
		{
			return true;
		}

		MvcModel::$InvalidFields[$parameterName] = $errorCode;

		return false;
	}

	public static function Url(&$value, $parameterName, $errorCode)
	{
		if (stripos($value, "http") >= 0 && filter_var($value, FILTER_VALIDATE_URL))
		{
			return true;
		}

		MvcModel::$InvalidFields[$parameterName] = $errorCode;

		return false;
	}

	public static function RegEx(&$value, $pattern, $parameterName, $errorCode)
	{
		if (preg_match($pattern, $value))
		{
			return true;
		}

		MvcModel::$InvalidFields[$parameterName] = $errorCode;

		return false;
	}

	public static function SetToNullIfEmpty(&$value)
	{
		if (empty($value))
			$value = null;
	}

	public static function SetToNullIfEmptyOrGlue(&$value, $glue = ';')
	{
		if (empty($value))
		{
			$value = null;
			return;
		}

		$value = implode($glue, $value);
	}
}

?>
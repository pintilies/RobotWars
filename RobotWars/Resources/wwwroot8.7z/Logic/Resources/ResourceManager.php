<?php

class ResourceManager
{
	public static $Language = "en";
	
	public static function Get($resourceId, $language = null)
	{
		if (!isset($language))
			$language = self::$Language;
		
		$val = CachingManager::Get(CachingConfig::$CacheBaseName_Resources."_".$resourceId."_".$language);
		
		if (!isset($val))
		{
			$val = ResourceDa::Get($resourceId, $language, ResourceConfig::$DefaultLanguage);
			
			if (!isset($val))
				throw new Exception("Resource [".$resourceId."] in language [".$language."] doesnt exist");
			
			CachingManager::Set(CachingConfig::$CacheBaseName_Resources."_".$resourceId."_".$language, $val);
		}

		return $val;
	}
	
	public static function GetEnabledLanguages()
	{
		$val = CachingManager::Get(CachingConfig::$CacheBaseName_Languages_Enabled);
		
		if (!isset($val))
		{
			$val = ArrayManager::ValuesAsKeys(ResourceDa::GetLanguages(true));
			
			CachingManager::Set(CachingConfig::$CacheBaseName_Languages_Enabled, $val);
		}
		
		return $val;
	}

	public static function GetLanguages()
	{
		$val = CachingManager::Get(CachingConfig::$CacheBaseName_Languages_All);
		
		if (!isset($val))
		{
			$val = ResourceDa::GetLanguages();
			
			CachingManager::Set(CachingConfig::$CacheBaseName_Languages_All, $val);
		}
		
		return $val;
	}
	
	public static function Init()
	{
	}
}

?>
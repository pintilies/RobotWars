<?php

include "SecurityRight.php";

class SecurityManager
{
	public static $WordsToMask;

	public static function Init()
	{
		self::$WordsToMask = SettingManager::Get(SettingConfig::$Name_SecuritySensitiveParameters,
			function($valM){
				$sep = array();

				foreach($valM as $key => $val)
				{
					$sep[] = array("[".$key."] => ", "\n");
					$sep[] = array($key."=", "&\n");
				}

				return $sep;
			});
	}

	public static function RequestCheck()
	{
		if (isset($_SESSION[SessionConfig::$Key_IsBlocked]))
		{
			LoggingManager::Clear();
			HttpHandler::End(null, 404);
		}

		$blockedIps = SettingManager::Get(SettingConfig::$Name_SecurityBlockedIps);

		foreach ($blockedIps as $ip => $val)
			if (fnmatch($ip, ServerConfig::$CallerIp))
			{
				$_SESSION[SessionConfig::$Key_IsBlocked] = true;
				LoggingManager::Log(LoggingConfig::$LogType_Warning, __FILE__, __CLASS__, __FUNCTION__, __LINE__, LoggingConfig::$Category_BlockedIp);
				HttpHandler::End(null, 404);
			}

		$blockedTemporary = CachingManager::Get(CachingConfig::$CacheBaseName_BannedIps.ServerConfig::$CallerIp);

		if (isset($blockedTemporary))
		{
			$_SESSION[SessionConfig::$Key_IsBlocked] = true;
			HttpHandler::End(null, 404);
		}
	}

	public static function CheckRightsWithRedirection($action)
	{
		$hasRight = self::CheckRights($action);

		if (!$hasRight)
		{
			LoggingManager::Log(LoggingConfig::$LogType_Warning, __FILE__, __CLASS__, __FUNCTION__, __LINE__, LoggingConfig::$Category_NoRights);
			HttpHandler::End(null, 404);
		}
	}

	public static function CheckRights($action)
	{
		if (!isset($action))
			return true;

		$rights = self::GetActionRights($action);

		if (!isset($rights))
			return false;

		$hasRight = false;

		foreach(UserManager::$UserTypes as $userType)
			if (array_key_exists($userType, $rights->UserTypes))
			{
				$hasRight = true;
				break;
			}

		if ($hasRight && isset($rights->AllowedIps) && !NetworkManager::IsStrInWildcharList(ServerConfig::$CallerIp, $rights->AllowedIps))
		{
			$hasRight = false;
		}

		if ($hasRight && isset($rights->DeniedIps) && NetworkManager::IsStrInWildcharList(UserManager::$CallerIp, $rights->DeniedIps))
		{
			$hasRight = false;
		}

		if ($hasRight && isset($rights->AllowedUserIds) && !array_key_exists(UserManager::$UserId, $rights->AllowedUserIds))
		{
			$hasRight = false;
		}

		if ($hasRight && isset($rights->DeniedUserIds) && array_key_exists(UserManager::$UserId, $rights->DeniedUserIds))
		{
			$hasRight = false;
		}

		return $hasRight;
	}

	public static function GetActionRights($action)
	{
		$rights = CachingManager::Get(CachingConfig::$CacheBaseName_Rights.ServerConfig::$Application."_".$action);

		if (!isset($rights))
		{
			$rightsRow = SecurityDa::GetRights(ServerConfig::$Application, $action);

			if (count($rightsRow) == 0)
			{
				LoggingManager::Log(LoggingConfig::$LogType_Error, __FILE__, __CLASS__, __FUNCTION__, __LINE__, LoggingConfig::$Category_NoRightsDefined, $action);
				return null;
			}

			$rightsRow = $rightsRow[0];

			if (!isset($rightsRow["UserTypes"]))
			{
				LoggingManager::Log(LoggingConfig::$LogType_Error, __FILE__, __CLASS__, __FUNCTION__, __LINE__, LoggingConfig::$Category_NoUserTypesDefined, $action);
				return null;
			}

			$rights = new SecurityRight();

			$rights->UserTypes = ArrayManager::ExplodeAsKeys(';', $rightsRow["UserTypes"], true);

			if (isset($rightsRow["AllowedIps"]))
			{
				$rights->AllowedIps = explode(';', $rightsRow["AllowedIps"]);
			}

			if (isset($rightsRow["DeniedIps"]))
			{
				$rights->DeniedIps = explode(';', $rightsRow["DeniedIps"]);
			}

			if (isset($rightsRow["AllowedUserIds"]))
			{
				$rights->AllowedUserIds = ArrayManager::ExplodetAsKeys(';', $rightsRow["AllowedUserIds"], true);
			}

			if (isset($rightsRow["DeniedUserIds"]))
			{
				$rights->DeniedUserIds = ArrayManager::ExplodetAsKeys(';', $rightsRow["DeniedUserIds"], true);
			}

			CachingManager::Set(CachingConfig::$CacheBaseName_Rights.ServerConfig::$Application."_".$action, $rights);
		}

		return $rights;
	}

	public static function MaskSensitiveData(&$str)
	{
		$containsSensitiveData = false;

		foreach (self::$WordsToMask as $word)
			if (strpos($str, $word[0]) >= 0)
			{
				$containsSensitiveData = true;
				break;
			}

		if ($containsSensitiveData)
			foreach (self::$WordsToMask as $word)
			{
				$split = explode($word[0], $str);

				$newStr = $split[0];

				for ($i = 1; $i < count($split); $i++)
				{
					$endOfLine = strlen($split[$i]);

					for ($j = 0; $j < strlen($word[1]); $j++)
					{
						$pos = strpos($split[$i], $word[1][$j]);

						if ($pos !== false)
							$endOfLine = min($endOfLine, $pos);
					}

					$newStr .= $word[0].str_repeat('X', $endOfLine).substr($split[$i], $endOfLine);
				}

				$str = $newStr;
			}

		//print_r($str);
	}

	public static function GetUserTypes()
	{
		$userTypes = CachingManager::Get(CachingConfig::$CacheBaseName_Rights_UserTypes);

		if (!isset($userTypes))
		{
			$userTypes = SecurityDa::GetUserTypes();

			foreach($userTypes as $key => &$value)
			{
				$value["Included"] = ArrayManager::ExplodeAsKeys(';', $value["Included"], true);
			}

			CachingManager::Set(CachingConfig::$CacheBaseName_Rights_UserTypes, $userTypes);
		}

		return $userTypes;
	}

	public static function GetUserTypeInclusions()
	{
		$userTypes = CachingManager::Get(CachingConfig::$CacheBaseName_Rights_UserTypeInclusions);

		if (!isset($userTypes))
		{
			$userTypes = SecurityDa::GetUserTypes();

			foreach($userTypes as $key => &$value)
			{
				$includedRights = isset($value["Included"]) ? explode(';', $value["Included"]) : array();

				foreach($includedRights as &$val)
					$val = intval($val);

				$includedRights[] = $key;
				$value = $includedRights;
			}

			CachingManager::Set(CachingConfig::$CacheBaseName_Rights_UserTypeInclusions, $userTypes);
		}

		return $userTypes;
	}
}

?>
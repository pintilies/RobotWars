<?php
class SecurityRight
{
	public $UserTypes;
	public $AllowedIps;
	public $DeniedIps;
	public $AllowedUserIds;
	public $DeniedUserIds;
}

?>
<?php

class SettingManager
{
	public static function Get($name, $transform = null)
	{
		$val = CachingManager::Get(CachingConfig::$CacheBaseName_Settings.$name);

		if (!isset($val))
		{
			$val = SettingDa::Get($name, $type);

			if (!isset($val))
				throw new Exception("Value for setting ".$name." doesn't exist");

			switch($type)
			{
				case SettingConfig::$Type_Boolean:
					$val = $val == 1;
					break;
				case SettingConfig::$Type_Integer:
					break;
				case SettingConfig::$Type_Decimal:
					break;
				case SettingConfig::$Type_DateTime:
					$val = new DateTime($val);
					break;
				case SettingConfig::$Type_CommaEqual:
					$val = ArrayManager::ExplodeAsKeys(";", $val);
					break;
				case SettingConfig::$Type_CommaEqualInt:
					$val = ArrayManager::ExplodeAsKeys(";", $val, true);
					break;
				case SettingConfig::$Type_CommaEqualKeyValue:
					$val = ArrayManager::ExplodeAsKeyValue(";", "=", $val);
					break;
				case SettingConfig::$Type_CommaEqualKeyIntValue:
					$val = ArrayManager::ExplodeAsKeyValue(";", "=", $val, true);
					break;
				case SettingConfig::$Type_CommaEqualKeyValueInt:
					$val = ArrayManager::ExplodeAsKeyValue(";", "=", $val, false, true);
					break;
				case SettingConfig::$Type_CommaEqualKeyIntValueInt:
					$val = ArrayManager::ExplodeAsKeyValue(";", "=", $val, true, true);
					break;
				case SettingConfig::$Type_Text:
					break;
				default:
					throw new Exception("Unknow type for setting ".$name);
			}

			if (isset($transform))
				$val = $transform($val);

			CachingManager::Set(CachingConfig::$CacheBaseName_Settings.$name, $val);
			CachingManager::Set(CachingConfig::$CacheBaseName_Settings_Types.$name, $type);
		}

		return $val;
	}


	public static function GetType($name)
	{
		$type = CachingManager::Get(CachingConfig::$CacheBaseName_Settings_Types.$name);

		if (!isset($type))
		{
			$type = SettingDa::GetType($name);

			if (!isset($type))
				throw new Exception("Setting ".$name." doesn't exist when trying to get the type");

			CachingManager::Set(CachingConfig::$CacheBaseName_Settings_Types.$name, $type);
		}

		return $type;
	}

	public static function Set($name, $value, $transform = null)
	{
		$type = self::GetType($name);

		switch($type)
		{
			case SettingConfig::$Type_Boolean:
				if (!is_bool($value))
					throw new Exception("Invalid value for the boolean setting ".$name);

				$val = $value ? 1 : 0;
				break;
			case SettingConfig::$Type_Integer:
				if (!is_int($value))
					throw new Exception("Invalid value for the integer setting ".$name);

				$val = $value;
				break;
			case SettingConfig::$Type_Decimal:
				if (!is_numeric($value))
					throw new Exception("Invalid value for the decimal setting ".$name);

				$val = $value;
				break;
			case SettingConfig::$Type_DateTime:
				if (!($value instanceof DateTime))
					throw new Exception("Invalid value for the date time setting ".$name);

				$val = $value;
				break;
			case SettingConfig::$Type_CommaEqual:
			case SettingConfig::$Type_CommaEqualInt:
				if (!is_array($value))
					throw new Exception("Invalid value for CommaEqual setting ".$name);

				$val = implode(";", array_keys($value));
				break;
			case SettingConfig::$Type_CommaEqualKeyValue:
			case SettingConfig::$Type_CommaEqualKeyIntValue:
			case SettingConfig::$Type_CommaEqualKeyValueInt:
			case SettingConfig::$Type_CommaEqualKeyIntValueInt:
				if (!is_array($value))
					throw new Exception("Invalid value for CommaEqualKeyValue setting ".$name);

				$valK = array();

				foreach ($value as $subVal)
				{
					$valK[] = $subVal[0]."=".$subVal[1];
				}

				$val = implode(";", $valK);
				break;
			case SettingConfig::$Type_Text:
				if (!is_string($value))
					throw new Exception("Invalid value for string setting ".$name);

				$val = strval($value);
				break;
			default:
				throw new Exception("Unknow type for setting ".$name);
		}

		SettingDa::Set($name, $val, $type);

		CachingManager::Set(CachingConfig::$CacheBaseName_Settings.$name, isset($transform) ? $transform : $value);
	}
}
?>
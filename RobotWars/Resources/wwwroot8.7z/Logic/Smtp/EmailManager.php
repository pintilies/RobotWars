<?php

include "PHPMailer/PHPMailer.php";
include "PHPMailer/class.phpmaileroauth.php";
include "PHPMailer/class.pop3.php";
include "PHPMailer/class.smtp.php";

class EmailManager
{
	public static function SendEmail($fromName, $fromAddr, $to, $subject, $body, $placeHolders = null, $stringAtt = null, $tries = 3)
	{
		//$placeholders = array('$$$count$$$' => 10000);
		//EmailManager::SendEmail(ResourceManager::Get(ResourceConfig::$Id_InternalMailFromName), ResourceManager::Get(ResourceConfig::$Id_InternalMailFromAddress), ResourceManager::Get(ResourceConfig::$Id_InternalMailToAddress), ResourceManager::Get(ResourceConfig::$Id_InternalMailSubjectSecurityOverallRequestLimitReached), ResourceManager::Get(ResourceConfig::$Id_InternalMailBodySecurityOverallRequestLimitReached), $placeholders);
		if (isset($placeHolders))
			foreach ($placeHolders as $key => $value)
			{
				$body = str_replace($key, $value, $body);
				$subject = str_replace($key, $value, $subject);
			}

		$email = new PHPMailer(true);
		$email->isHTML();
		$email->Host = EmailConfig::$Host;
		$email->Port = EmailConfig::$Port;
		$email->From      = $fromAddr;
		$email->FromName  = $fromName;
		$email->Subject   = $subject;
		$email->Body      = $body;
		$email->AddAddress( $to);


		if (isset($stringAtt))
			foreach ($stringAtt as $name => $content)
			{
				$email->addStringAttachment($content, $name);
			}

		$emailSent = false;
		$lastException = null;

		for ($i = 0; $i < $tries; $i++)
			try
			{
				if ($email->Send())
				{
					$emailSent = true;
					break;
				}
			}
			catch(Exception $ex)
			{
				$lastException = $ex;
			}


		if (isset($lastException))
			LoggingManager::Log(LoggingConfig::$LogType_Warning, __FILE__, __CLASS__, __FUNCTION__, __LINE__, LoggingConfig::$Category_SendingEmailError, $lastException);

		return $emailSent;
	}
}
?>
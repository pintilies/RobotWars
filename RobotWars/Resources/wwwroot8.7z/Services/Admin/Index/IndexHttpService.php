<?php

class IndexHttpService
{
	public static function Index()
	{
	}
}

?>
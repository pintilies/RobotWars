
<html>
<head>
	<title>
		<?=MvConnectParams::$Title?>
	</title>
	<link rel="stylesheet" type="text/css" href="/content/css/adminStyle.css" />
</head>
<body>
	<table class="mainTable" cellpadding="0" cellspacing="0">
		<tr class="headerRow">
			<td>
				<a href="<?=HttpResponse::GetUrl()?>" class="homeLink">
					<?=ResourceManager::Get(8)?>
				</a>
			</td>
		</tr>
		<tr class="menuRow">
			<td>
				<a href="<?=HttpResponse::GetUrl("rights")?>" class="menuLink">
					<?=ResourceManager::Get(10)?>
				</a>
				<a href="<?=HttpResponse::GetUrl("usertypes")?>" class="menuLink">
					<?=ResourceManager::Get(15)?>
				</a>
			</td>
		</tr>
		<tr class="middleRow">
			<td>
				<div class="container">
					<?php MvcManager::RenderBody() ?>
				</div>
				<!--<div class="sideMenu">
						Banners here
					</div>-->
			</td>
		</tr>
		<tr class="footerRow">
			<td>
				<?php if (UserManager::$IsMobile) echo "Switch to desktop view"; else echo "Switch to mobile view";?>
			</td>
		</tr>
	</table>
</body>
</html>
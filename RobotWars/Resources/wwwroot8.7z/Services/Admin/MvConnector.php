<?php
class MvConnector
{
	public static $Title;

	public static function Bridge($controller, $action)
	{
		MvConnectParams::$Title = ResourceManager::Get(8);

		switch (strtolower($controller))
		{
			case 'index':
				MvConnectParams::$Title .= ' - '.ResourceManager::Get(11);
				MvConnectParams::$Response = 'Index';
				break;
			case 'rights':
				MvConnectParams::$Title .= ' - '.ResourceManager::Get(10);

				switch(MvcModel::$Step)
				{
					case 0:
						MvConnectParams::$Response = 'Index';
						break;
					case 1:
						MvConnectParams::$Response = 'Add';
						break;
				}
				break;
			case 'usertypes':
				MvConnectParams::$Title .= ' - '.ResourceManager::Get(15);
				MvConnectParams::$Response = 'Index';
				break;
			default:
		}

		if (!isset(MvConnectParams::$Layout))
			MvConnectParams::$Layout = '/Admin';

		if (!isset(MvConnectParams::$Response))
			MvConnectParams::$Response = $action;

		if (UserManager::$IsMobile)
		{
			if (file_exists(MvcConfig::$HttpServiceRoot.MvcConfig::$LayoutRoot.MvConnectParams::$Layout."_M_Layout.php"))
				MvConnectParams::$Layout .= '_M_';

			if (file_exists(MvcConfig::$HttpServiceRoot."/".$controller."/".MvConnectParams::$Response."_M_Response.php"))
				MvConnectParams::$Response .= '_M_';
		}
	}
}

?>
<div class="rightsIndexContainer">
	<form action="<?=HttpResponse::GetUrl("rights", "search")?>" method="get">
		<input type="text" name="search" value="<?=isset(MvcModel::$Data['Search']) ? htmlspecialchars(MvcModel::$Data['Search']) : "" ?>" />
		<input type="submit" value="<?=ResourceManager::Get(9)?>" />
	</form>
</div>

<?php
HtmlManager::Errors(MvcModel::$Errors);
HtmlManager::Errors(MvcModel::$InvalidFields);
HtmlManager::HighlightFieldError(MvcModel::$InvalidFields);
?>
<div class="searchRightsTable table">
	<div class="thead">
		<div class="thead1">
			<?=ResourceManager::Get(13)?>
		</div>
		<div class="thead2">
			<?=ResourceManager::Get(14)?>
		</div>
		<div class="thead3">
			<?=ResourceManager::Get(15)?>
		</div>
		<div class="thead4">
			<?=ResourceManager::Get(16)?>
		</div>
		<div class="thead5">
			<?=ResourceManager::Get(17)?>
		</div>
		<div class="thead6">
			<?=ResourceManager::Get(18)?>
		</div>
		<div class="thead7">
			<?=ResourceManager::Get(26)?>
		</div>
		<div class="thead8">&nbsp;</div>
		<div class="thead9 last">&nbsp;</div>
	</div>
	<div class="trows">
		<form action="<?=HttpResponse::GetUrl("rights", "add")?>" method="post">
<?php if (isset(MvcModel::$Data['SearchResult'])) {?>
			<input type="hidden" name="search" value="<?=htmlspecialchars(MvcModel::$Data['Search'])?>" />
			<input type="hidden" name="page" value="<?=htmlspecialchars(MvcModel::$Data['Page'])?>" />
<?php }?>
			<div class="trow1">
				<input type="text" name="application" value="<?=isset(MvcModel::$Data["NewApplication"]) ? htmlspecialchars(MvcModel::$Data["NewApplication"]) : ""?>" />
			</div>
			<div class="trow2">
				<input type="text" name="action" value="<?=isset(MvcModel::$Data["NewAction"]) ? htmlspecialchars(MvcModel::$Data["NewAction"]) : ""?>" />
			</div>
			<div class="trow3">
<?php
		$first = true;
		$isValueNewUserTypeArray = isset(MvcModel::$Data["NewUserTypes"]) && is_array(MvcModel::$Data["NewUserTypes"]);

		foreach (MvcModel::$Data["UserTypes"] as $userTypeId => $userTypeDet)
		{
?>
				<span class="checkbox"><input type="checkbox" name="userTypes[]" value="<?=$userTypeId?>" <?=$isValueNewUserTypeArray && array_key_exists($userTypeId, MvcModel::$Data["NewUserTypes"]) ? 'checked=checked' : '' ?> /><?=htmlspecialchars($userTypeDet["Name"])?></span>
<?php
		}
?>
			</div>
			<div class="trow4">
				<input type="text" name="allowedIps" value="<?=isset(MvcModel::$Data["NewAllowedIps"]) ? htmlspecialchars(MvcModel::$Data["NewAllowedIps"]) : ''?>" />
			</div>
			<div class="trow5">
				<input type="text" name="deniedIps" value="<?=isset(MvcModel::$Data["NewDeniedIps"]) ? htmlspecialchars(MvcModel::$Data["NewDeniedIps"]) : ''?>" />
			</div>
			<div class="trow6">
				<input type="text" name="allowedUserIds" value="<?=isset(MvcModel::$Data["NewAllowedUserIds"]) ? htmlspecialchars(MvcModel::$Data["NewAllowedUserIds"]) : ''?>" />
			</div>
			<div class="trow7">
				<input type="text" name="deniedUserIds" value="<?=isset(MvcModel::$Data["NewDeniedUserIds"]) ? htmlspecialchars(MvcModel::$Data["NewDeniedUserIds"]) : ''?>" />
			</div>
			<div class="trow8 last">
				<input type="submit" value="<?=htmlspecialchars(ResourceManager::Get(30))?>" />
			</div>
		</form>
<?php
if (isset(MvcModel::$Data['SearchResult']))
{
	foreach(MvcModel::$Data['SearchResult'] as $right)
	{
?>
		<div class="trow">
			<form action="<?=HttpResponse::GetUrl("rights", "update")?>" method="post">
				<input type="hidden" name="search" value="<?=htmlspecialchars(MvcModel::$Data['Search'])?>"></form>
				<input type="hidden" name="page" value="<?=htmlspecialchars(MvcModel::$Data['Page'])?>" />
				<input type="hidden" name="currentApplication" value="<?=htmlspecialchars($right["Application"])?>" />
				<input type="hidden" name="currentAction" value="<?=htmlspecialchars($right["Action"])?>" />
				<div class="trow1">
					<input type="text" name="application" size="" value="<?=htmlspecialchars($right["Application"])?>" />
				</div>
				<div class="trow2">
					<input type="text" name="action" value="<?=htmlspecialchars($right["Action"])?>" />
				</div>
				<div class="trow3">
<?php
		$userTypes = ArrayManager::ExplodeAsKeys(';', $right["UserTypes"], true);
		$first = true;
		foreach (MvcModel::$Data["UserTypes"] as $userTypeId => $userTypeDet)
		{
?>
					<span class="checkbox"><input type="checkbox" name="userTypes[]" value="<?=$userTypeId?>" <?=array_key_exists($userTypeId, $userTypes) ? 'checked="checked"' : ''?> /><?=htmlspecialchars($userTypeDet["Name"])?></span>
<?php
		}
?>
				</div>
				<div class="trow5">
					<input type="text" name="allowedIps" value="<?=htmlspecialchars($right["AllowedIps"])?>" />
				</div>
				<div class="trow5">
					<input type="text" name="deniedIps" value="<?=htmlspecialchars($right["DeniedIps"])?>" />
				</div>
				<div class="trow6">
					<input type="text" name="allowedUserIds" value="<?=htmlspecialchars($right["AllowedUserIds"])?>" />
				</div>
				<div class="trow7">
					<input type="text" name="deniedUserIds" value="<?=htmlspecialchars($right["DeniedUserIds"])?>" />
				</div>
				<div class="trow8">
					<input type="submit" value="<?=htmlspecialchars(ResourceManager::Get(19))?>" />
				</div>
			</form>
			<div class="trow9">
				<form action="<?=HttpResponse::GetUrl("rights", "delete")?>" method="post" onsubmit="return confirm('<?=ResourceManager::Get(41)?>')">
					<input type="hidden" name="search" value="<?=htmlspecialchars(MvcModel::$Data['Search'])?>" />
					<input type="hidden" name="page" value="<?=htmlspecialchars(MvcModel::$Data['Page'])?>" />
					<input type="hidden" name="application" value="<?=htmlspecialchars($right["Application"])?>" />
					<input type="hidden" name="action" value="<?=htmlspecialchars($right["Action"])?>" />
					<input type="submit" value="<?=htmlspecialchars(ResourceManager::Get(20))?>" />
				</form>
			</div>
		</div>
<?php }	?>
	</div>
<?php HtmlManager::AddPaging(HttpResponse::GetUrl("rights", "search", null, array('page' => '$$$page$$$', 'search'=> MvcModel::$Data['Search'])), HttpConfig::$PageSize, HttpConfig::$PageScrolling,  MvcModel::$Data['Page'], MvcModel::$Data['TotalRightCount'],HttpConfig::$PageFastScrollLeftString, HttpConfig::$PageScrollLeftString, HttpConfig::$PageScrollRightString, HttpConfig::$PageFastScrollRightString) ?>
<?php }?>
</div>

<?php

class RightsHttpService
{
	public static function Index()
	{
		MvcModel::$Data['UserTypes'] = SecurityManager::GetUserTypes();
	}

	public static function Search($search, $page)
	{
		MvcModel::$Data['UserTypes'] = SecurityManager::GetUserTypes();

		if (!MvcModel::IsValid())
			return;

		self::UpdateSearchResults($search, $page);
	}

	public static function Update($search, $page, $currentApplication, $currentAction, $application, $action, $userTypes, $allowedIps, $deniedIps, $allowedUserIds, $deniedUserIds)
	{
		MvcModel::$Data['UserTypes'] = SecurityManager::GetUserTypes();

		if (!MvcModel::IsValid())
		{
			self::UpdateSearchResults($search, $page);
			return;
		}

		ValidatorManager::SetToNullIfEmpty($allowedIps);
		ValidatorManager::SetToNullIfEmpty($deniedIps);
		ValidatorManager::SetToNullIfEmpty($allowedUserIds);
		ValidatorManager::SetToNullIfEmpty($deniedUserIds);

		SecurityDa::UpdateRight($currentApplication, $currentAction, $application, $action, implode(';', $userTypes), $allowedIps, $deniedIps, $allowedUserIds, $deniedUserIds);

		CachingManager::Remove(CachingConfig::$CacheBaseName_Rights.$currentApplication."_".$currentAction);
		self::UpdateSearchResults($search, $page);
	}

	public static function Add($search, $page, $application, $action, $userTypes, $allowedIps, $deniedIps, $allowedUserIds, $deniedUserIds)
	{
		MvcModel::$Data['UserTypes'] = SecurityManager::GetUserTypes();

		if (!MvcModel::IsValid())
		{
			if (isset($search))
				self::UpdateSearchResults($search, $page);

			self::AddNewActionData($application, $action, $userTypes, $allowedIps, $deniedIps, $allowedUserIds, $deniedUserIds);
			return;
		}

		ValidatorManager::SetToNullIfEmpty($allowedIps);
		ValidatorManager::SetToNullIfEmpty($deniedIps);
		ValidatorManager::SetToNullIfEmpty($allowedUserIds);
		ValidatorManager::SetToNullIfEmpty($deniedUserIds);

		SecurityDa::InsertRight($application, $action, implode(';', $userTypes), $allowedIps, $deniedIps, $allowedUserIds, $deniedUserIds);

		MvcModel::$Step = 1;
	}

	public static function Delete($search, $page, $application, $action)
	{
		MvcModel::$Data['UserTypes'] = SecurityManager::GetUserTypes();

		if (!MvcModel::IsValid())
		{
			self::UpdateSearchResults($search, $page);
			return;
		}

		SecurityDa::DeleteRight($application, $action);

		CachingManager::Remove(CachingConfig::$CacheBaseName_Rights.$application."_".$action);
		self::UpdateSearchResults($search, $page);
	}

	private static function AddNewActionData($application, $action, $userTypes, $allowedIps, $deniedIps, $allowedUserIds, $deniedUserIds)
	{
		MvcModel::$Data['NewApplication'] = $application;
		MvcModel::$Data['NewAction'] = $action;
		MvcModel::$Data['NewUserTypes'] = ArrayManager::ValuesAsKeys($userTypes);
		MvcModel::$Data['NewAllowedIps'] = $allowedIps;
		MvcModel::$Data['NewDeniedIps'] = $deniedIps;
		MvcModel::$Data['NewAllowedUserIds'] = $allowedUserIds;
		MvcModel::$Data['NewDeniedUserIds'] = $deniedUserIds;
	}

	private static function UpdateSearchResults($search, $page)
	{
		MvcModel::$Data['SearchResult'] = SecurityDa::SearchRights($search, $page * HttpConfig::$PageSize, HttpConfig::$PageSize, $totalRows);
		MvcModel::$Data['Search'] = $search;
		MvcModel::$Data['Page'] = $page;
		MvcModel::$Data['TotalRightCount'] = $totalRows;
	}
}

?>
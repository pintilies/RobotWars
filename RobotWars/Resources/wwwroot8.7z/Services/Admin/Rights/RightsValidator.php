<?php

class RightsValidator
{
	public static function Search(&$search, &$page = 0)
	{
		if (ValidatorManager::Int($page, 'page', 12))
			ValidatorManager::MinValue($page, 0, 'page', 12);

		if (!MvcModel::IsValid())
		{
			$page = 0;
			MvcModel::$InvalidFields = array();
		};
	}

	public static function Update(&$search, &$page, &$currentApplication, &$currentAction, &$application, &$action, &$userTypes, &$allowedIps, &$deniedIps, &$allowedUserIds, &$deniedUserIds)
	{
		if (ValidatorManager::Int($page, 'page', 12))
			ValidatorManager::MinValue($page, 0, 'page', 12);

		if (!MvcModel::IsValid())
		{
			$page = 0;
			MvcModel::$InvalidFields = array();
		};

		ValidatorManager::NotEmpTrim($currentApplication, 'currentApplication', 21);
		ValidatorManager::NotEmpTrim($currentAction, 'currentAction', 21);
		ValidatorManager::NotEmpTrim($application, 'application', 22);
		ValidatorManager::NotEmpTrim($action, 'action', 23);

		if (ValidatorManager::Arr($userTypes, 'userTypes', 24))
			if (ValidatorManager::NotEmp($userTypes, 'userTypes', 24))
				if (ValidatorManager::ArrValInt($userTypes, 'userTypes', 24))
					ValidatorManager::ArrValInArrKey($userTypes, SecurityManager::GetUserTypeInclusions(), 'userTypes', 24);

		if (!empty($allowedUserIds))
			ValidatorManager::ArrValInt(explode(';', $allowedUserIds), 'allowedUserIds', 25);

		if (!empty($deniedUserIds))
			ValidatorManager::ArrValInt(explode(';', $deniedUserIds), 'deniedUserIds', 25);

		if (!MvcModel::IsValid())
		{
			return;
		}

		if ($application != $currentApplication || $action != $currentApplication)
		{
			$rights = SecurityDa::GetRights($application, $action);

			if (!empty($rights))
				MvcModel::$Errors[] = 32;
		}

	}
	public static function Delete(&$search, &$page, &$application, &$action)
	{
		if (ValidatorManager::Int($page, 'page', 12))
			ValidatorManager::MinLength($page, 0, 'page', 12);

		if (!MvcModel::IsValid())
		{
			$page = 0;
			MvcModel::$InvalidFields = array();
		};

		ValidatorManager::NotEmpTrim($application, 'application', 22);
		ValidatorManager::NotEmpTrim($action, 'action', 23);
	}

	public static function Add(&$search = null, &$page = 0, &$application, &$action, &$userTypes, &$allowedIps, &$deniedIps, &$allowedUserIds, &$deniedUserIds)
	{
		if (ValidatorManager::Int($page, 'page', 12))
			ValidatorManager::MinLength($page, 0, 'page', 12);

		if (!MvcModel::IsValid())
		{
			$page = 0;
			MvcModel::$InvalidFields = array();
		};

		ValidatorManager::NotEmpTrim($application, 'application', 22);
		ValidatorManager::NotEmpTrim($action, 'action', 23);

		if (ValidatorManager::Arr($userTypes, 'userTypes', 24))
			if (ValidatorManager::NotEmp($userTypes, 'userTypes', 24))
				if (ValidatorManager::ArrValInt($userTypes, 'userTypes', 24))
					ValidatorManager::ArrValInArrKey($userTypes, SecurityManager::GetUserTypeInclusions(), 'userTypes', 24);

		if (!empty($allowedUserIds))
			ValidatorManager::ArrValInt(explode(';', $allowedUserIds), 'allowedUserIds', 25);

		if (!empty($deniedUserIds))
			ValidatorManager::ArrValInt(explode(';', $deniedUserIds), 'deniedUserIds', 25);

		if (!MvcModel::IsValid())
			return;

		$rights = SecurityDa::GetRights($application, $action);

		if (!empty($rights))
			MvcModel::$Errors[] = 32;
	}

}
?>
<?php
HtmlManager::Errors(MvcModel::$Errors);
HtmlManager::Errors(MvcModel::$InvalidFields);
HtmlManager::HighlightFieldError(MvcModel::$InvalidFields);
?>
<div class="userTypeTable table">
	<div class="thead">
		<div class="thead1">
			<?=ResourceManager::Get(38)?>
		</div>
		<div class="thead2">
			<?=ResourceManager::Get(39)?>
		</div>
		<div class="thead3">
			<?=ResourceManager::Get(40)?>
		</div>
		<div class="thead4 last">&nbsp;</div>
	</div>
	<div class="trows">
		<div class="trow">
			<form action="<?=HttpResponse::GetUrl("usertypes", "add")?>" method="post">
				<div class="trow1">
				</div>
				<div class="trow2">
					<input type="text" name="name" value="<?=isset(MvcModel::$Data["NewName"]) ? htmlspecialchars(MvcModel::$Data["NewApplication"]) : ""?>" />
				</div>
				<div class="trow3">
<?php
				$first = true;
				$isValueNewIncludedArray = isset(MvcModel::$Data["NewIncluded"]) && is_array(MvcModel::$Data["NewIncluded"]);

				foreach (MvcModel::$Data["UserTypes"] as $userTypeId => $userTypeDet)
				{
?>
					<span class="checkbox"><input type="checkbox" name="included[]" value="<?=$userTypeId?>" <?=$isValueNewIncludedArray && array_key_exists($userTypeId, MvcModel::$Data["NewIncluded"]) ? 'checked=checked' : '' ?> /><?=htmlspecialchars($userTypeDet["Name"])?></span>
<?php
				}
?>
				</div>
				<div class="trow4 last">
					<input type="submit" value="<?=htmlspecialchars(ResourceManager::Get(30))?>" />
				</div>
			</form>
		</div>
		<?php

			foreach(MvcModel::$Data['UserTypes'] as $userTypeId => $userType)
			{
		?>
		<div class="trow">
			<form action="<?=HttpResponse::GetUrl("usertypes", "update")?>" method="post">
				<input type="hidden" name="userTypeId" value="<?=htmlspecialchars($userTypeId)?>" />
				<div class="trow1">
					<?=htmlspecialchars($userType['Id'])?>
				</div>
				<div class="trow2">
					<input type="text" name="name" value="<?=htmlspecialchars($userType['Name'])?>" />
				</div>
				<div class="trow3">
<?php
				foreach (MvcModel::$Data["UserTypes"] as $userTypeId2 => $userTypeDet2)
					if ($userTypeId2 != $userTypeId)
				{
?>
					<span class="checkbox"><input type="checkbox" name="included[]" value="<?=$userTypeId2?>" <?=array_key_exists($userTypeId2, $userType["Included"]) ? 'checked="checked"' : ''?> /><?=htmlspecialchars($userTypeDet2["Name"])?></span>
<?php
				}
?>
				</div>
				<div class="trow8">
					<input type="submit" value="<?=htmlspecialchars(ResourceManager::Get(19))?>" />
				</div>
			</form>
		</div>
<?php		}	?>
	</div>
</div>

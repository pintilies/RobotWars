<?php
class UserTypesHttpService
{
	public static function Index()
	{
		MvcModel::$Data["UserTypes"] = SecurityManager::GetUserTypes();
	}

	public static function Update($userTypeId, $name, $included)
	{
		if (!MvcModel::IsValid())
		{
			MvcModel::$Data["UserTypes"] = SecurityManager::GetUserTypes();
			return;
		}

		ValidatorManager::SetToNullIfEmptyOrGlue($included);

		SecurityDa::UpdateUserType($userTypeId, $name, $included);

		CachingManager::Remove(CachingConfig::$CacheBaseName_Rights_UserTypes);
		CachingManager::Remove(CachingConfig::$CacheBaseName_Rights_UserTypeInclusions);
		MvcModel::$Data["UserTypes"] = SecurityManager::GetUserTypes();
	}

	public static function Add($name, $included)
	{
		if (!MvcModel::IsValid())
		{
			MvcModel::$Data["UserTypes"] = SecurityManager::GetUserTypes();
			MvcModel::$Data["NewName"] = $name;
			MvcModel::$Data["Included"] = $included;
			return;
		}

		ValidatorManager::SetToNullIfEmptyOrGlue($included);

		SecurityDa::InsertUserType($name, $included);

		CachingManager::Remove(CachingConfig::$CacheBaseName_Rights_UserTypes);
		CachingManager::Remove(CachingConfig::$CacheBaseName_Rights_UserTypeInclusions);

		MvcModel::$Data["UserTypes"] = SecurityManager::GetUserTypes();
	}
}
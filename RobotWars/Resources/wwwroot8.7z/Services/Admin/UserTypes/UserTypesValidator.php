<?php
class UserTypesValidator
{
	public static function Update(&$userTypeId, &$name, &$included)
	{
		$userTypes = SecurityManager::GetUserTypes();

		if (ValidatorManager::Int($userTypeId, "userTypeId", 35))
			ValidatorManager::InArrKey($userTypeId, $userTypes, "userTypeId", 35);


		if (ValidatorManager::NotEmp($name, "name", 36))
		{
			foreach($userTypes as $cUserTypeId => $val)
				if ($userTypeId != $cUserTypeId && $val["Name"] == $name)
				{
					MvcModel::$InvalidFields["name"] = 36;
					break;
				}
		}

		if (ValidatorManager::Arr($included, "included", 37))
			if (ValidatorManager::ArrValInt($included, "included", 37))
			{
				foreach ($included as $value)
					if (!array_key_exists($value, $userTypes) || $value == $userTypeId)
					{
						MvcModel::$InvalidFields["included"] = 37;
						break;
					}
			}
	}

	public static function Add(&$name, &$included)
	{
		$userTypes = SecurityManager::GetUserTypes();

		if (ValidatorManager::NotEmp($name, "name", 36))
		{
			foreach($userTypes as $val)
				if ($val["Name"] == $name)
				{
					MvcModel::$InvalidFields["name"] = 36;
					break;
				}
		}

		if (ValidatorManager::Arr($included, "included", 37))
			if (ValidatorManager::ArrValInt($included, "included", 37))
			{
				foreach ($included as $value)
					if (!array_key_exists($value, $userTypes))
					{
						MvcModel::$InvalidFields["included"] = 37;
						break;
					}
			}
	}
}
<?php

class AuthenticationHttpService
{
	public static function Login($username = null, $password = null)
	{
		if (isset($username) || isset($password))
			//return array(MvcConfig::$ReturnString, "Just dummy error message");
			MvcModel::$Errors[] = 123;
		
	}
}

?>
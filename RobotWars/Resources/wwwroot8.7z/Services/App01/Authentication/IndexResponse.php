<form method="post" action="<?=MvcManager::GetUrl("authentication", "login", true)?>"/>
<input type="hidden" name="<?=MvcConfig::$MainControllerParamName?>" value="<?=MvcManager::GetCurrentUrl()?>"/>
<input type="text" name="username"/><br/>
<input type="password" name="password"/></br>
<input type="submit" text="Submit"/>
</form>
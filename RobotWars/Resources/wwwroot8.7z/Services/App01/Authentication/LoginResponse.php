<form method="post" action="<?=HttpResponse::GetCurrentUrl()?>"/>
<input type="hidden" name="<?=MvcConfig::$SubActionPrefix?>" value="<?=HttpResponse::GetUrl("Authentication", "Login", array("Article", "123"))?>"/>
	<table class="login">
		<tr>
			<td>Username: </td>
			<td><input type="text" name="<?=MvcConfig::$SubActionPrefix?>username"/></td>
		</tr>
		<tr>
			<td>Password:</td>
			<td><input type="password" name="<?=MvcConfig::$SubActionPrefix?>password"/> </td>
		</tr>
		<tr>
			<td colspan="2" align="center">
				<input type="submit" value="Log In"/>
			</td>
		</tr>
	</table>
</form>

<?php if (count(MvcModel::$Errors) > 0){?>
Username or password wrong
<?php } ?>

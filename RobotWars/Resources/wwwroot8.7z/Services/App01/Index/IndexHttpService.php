<?php

class IndexHttpService
{
	public static function Index($param)
	{
		MvcModel::$Data = array("Text" => $param);
	}
}

?>
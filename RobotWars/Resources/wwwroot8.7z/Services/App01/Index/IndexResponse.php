<?=MvcModel::$Data["Text"]?>

<img src="https://static.pexels.com/photos/4825/red-love-romantic-flowers-large.jpg"/></br>

<img src="https://static.pexels.com/photos/92997/pexels-photo-92997-large.jpeg"/></br>


<html>
	<head>
		<title><?=MvConnectParams::$Title?></title>
		<link rel="stylesheet" type="text/css" href="/content/css/style.css">
	</head>
	<body>
		<table class="mainTable">
			<tr class="headerRow">
				<td align=right>
				<?php MvcManager::RenderPartial("Authentication", "Login")?>
				</td>
			</tr>
			<tr class="middleRow">
				<td align="center" valign="middle">
				<?php MvcManager::RenderBody() ?>
				</td>
			</tr>
			<tr class="footerRow">
				<td>
					<?php if (UserManager::$IsMobile) echo "Switch to desktop view"; else echo "Switch to mobile view";?>
				</td>
			</tr>
		</table>
	</body>
</html>
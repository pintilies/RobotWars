<?php
class MvConnector
{
	public static $Title;
	
	public static function Bridge($controller, $action)
	{
		if (strcasecmp($controller, "Index") == 0)
		{
			if (strcasecmp($action, "Index") == 0)
			{
				MvConnectParams::$Title = ResourceManager::Get(1);
			}
		}
		else if (strcasecmp($controller, "Authentication") == 0)
		{
			// if (strcasecmp($action, "Login") == 0)
			// {
				// MvConnectParams::$Response = "WrongLogin";
			// }
		}

		if (!isset(MvConnectParams::$Layout))
			MvConnectParams::$Layout = MvcConfig::$DefaultLayout;

		if (!isset(MvConnectParams::$Response))
			MvConnectParams::$Response = $action;
		
		if (UserManager::$IsMobile)
		{
			if (file_exists(MvcConfig::$HttpServiceRoot.MvcConfig::$LayoutRoot.MvConnectParams::$Layout."_M_Layout.php"))
				MvConnectParams::$Layout .= "_M_";
				
			if (file_exists(MvcConfig::$HttpServiceRoot."/".$controller."/".MvConnectParams::$Response."_M_Response.php"))
				MvConnectParams::$Response .= "_M_";
		}
	}
}

?>
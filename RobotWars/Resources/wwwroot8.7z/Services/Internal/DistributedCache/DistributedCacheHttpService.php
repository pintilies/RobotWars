<?php

class DistributedCacheHttpService
{
	public static function Dispatch()
	{
		SecurityManager::CheckHttpServiceRights();
		
		$caches = CachingDa::GetExpiredCaches();

		//throw new Exception("Exception in CacheHttpServie");
		
		if (count($caches) > 0)
		{
			self::Clear($caches);
			
			echo "Sending clearing cache for ";
			print_r($caches);
			$threads = array();
			$get = implode("&", array_map(function($val){ return "caches[]=".urlencode($val);}, $caches));
			
			for($i = 0; $i < count(CachingConfig::$Clients); $i++)
			{
				$thread = new CacheDispatcherThread(CachingConfig::$Clients[$i]."?".$get);
				$thread->start();
				array_push($threads, $thread);
			}
			
			foreach($threads as $thread)
				$thread->join();
				
			CachingDa::ClearExpiration($caches);
		}
			
		return array(MvcConfig::$ReturnString, "Ended");
	}
	
	public static function Clear($caches)
	{
		SecurityManager::CheckHttpServiceRights();
		
		if (is_array($caches))
		{
			foreach($caches as $cache)
				CachingManager::Remove($cache);
		}
		
		return array(MvcConfig::$ReturnString, "Done");
	}
}

?>
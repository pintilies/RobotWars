<?php
class SecurityCheckHttpService
{
	public static function Check()
	{
		$logTable = SettingManager::Get(SettingConfig::$Name_LoggingTable);
		$allowRequestHosts = SettingManager::Get(SettingConfig::$Name_SecurityAllowedCrawlers);
		$newRequestLimit = SettingManager::Get(SettingConfig::$Name_SecurityNewRequestCountLimit);
		$sameIpRequestLimit = SettingManager::Get(SettingConfig::$Name_SecuritySameIpRequestCountLimit);

		foreach ($newRequestLimit as $time => $limit)
		{
			$fromDate = DateTimeManager::GetUtcNow();
			$fromDate->sub(new DateInterval("PT".$time."S"));
			$count = SecurityDa::GetOverAllRequestCount($logTable, $fromDate, $allowRequestHosts);

			if ($count >= $limit)
			{
				$placeholders = array('$$$count$$$' => $count);

				EmailManager::SendEmail(ResourceManager::Get(ResourceConfig::$Id_InternalMailFromName), ResourceManager::Get(ResourceConfig::$Id_InternalMailFromAddress), ResourceManager::Get(ResourceConfig::$Id_InternalMailToAddress), ResourceManager::Get(ResourceConfig::$Id_InternalMailSubjectSecurityOverallRequestLimitReached), ResourceManager::Get(ResourceConfig::$Id_InternalMailBodySecurityOverallRequestLimitReached), $placeholders);

				SettingManager::Set(SettingConfig::$Name_MaintenanceEnabled, true);

				break;
			}
		}

		$blockedIps = array();

		foreach ($sameIpRequestLimit as $time => $limit)
		{
			$fromDate = DateTimeManager::GetUtcNow();
			$fromDate->sub(new DateInterval("PT".$time."S"));
			$ips = SecurityDa::GetRequestByIpOverLimit($logTable, $fromDate, $limit, $allowRequestHosts);

			foreach ($ips as $value)
			{
				$ip = $value["Ip"];

				if (!array_key_exists($ip, $blockedIps))
				{
					CachingManager::Set(CachingConfig::$CacheBaseName_BannedIps.ServerConfig::$CallerIp, true);
					$count = $value["N"];
					$blockedIps[$ip] = 1;
					$placeholders = array('$$$ip$$$' => $ip, '$$$count$$$' => $count);

					EmailManager::SendEmail(ResourceManager::Get(ResourceConfig::$Id_InternalMailFromName), ResourceManager::Get(ResourceConfig::$Id_InternalMailFromAddress), ResourceManager::Get(ResourceConfig::$Id_InternalMailToAddress), ResourceManager::Get(ResourceConfig::$Id_InternalMailSubjectSecurityIpRequestLimitReached), ResourceManager::Get(ResourceConfig::$Id_InternalMailBodySecurityIpRequestLimitReached), $placeholders);
				}
			}
		}

		MvcModel::$Result = MvcConfig::$ModelResult_Html;
		MvcModel::$Data = "Done";
	}
}
?>